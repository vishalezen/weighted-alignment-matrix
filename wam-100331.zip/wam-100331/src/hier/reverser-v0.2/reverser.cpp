#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <vector>

using namespace std;

/************************************************
  version
************************************************/
void version()
{
	cout << "----------------------------------------\n"
		    " reverser v0.2\n"
			" 2010/03/03 - 2010/03/03\n"
			" (c) 2008-2010 Yang Liu\n"
			"----------------------------------------\n";
}

/************************************************
  dump
************************************************/
void dump(map<pair<string, string>, vector<float> >& m,
		  const char* fileName)
{
	ofstream out(fileName);
	map<pair<string, string>, vector<float> >::iterator iter;

	for (iter = m.begin(); iter != m.end(); iter++)
	{
		out << iter->first.first
			<< " ||| "
			<< iter->first.second
			<< " ||| "
			<< iter->second[0]
			<< " "
			<< iter->second[1]
			<< " "
			<< iter->second[2]
			<< endl;
	}

	m.clear();
}

/************************************************
  main function
************************************************/
int main(int argc, char** argv)
{
	// version
	version();

	if (argc != 3)
	{
		cerr << "Usage: reverser input maxCapacity" << endl;
		exit(1);
	}

	ifstream in(argv[1]);
	float max_capacity = atof(argv[2]);
	string line;
	map<pair<string, string>, vector<float> > m;
	int fileID = 0;

	while (getline(in, line))
	{
		if (line.find("|||") == string::npos)
		{
			continue;
		}

		// source rhs
		int spp1 = 0,
			spp2 = line.find(" ||| ", spp1);
		string src_rhs = line.substr(spp1, spp2 - spp1);

		// target rhs
		spp1 = spp2 + 5;
		spp2 = line.find(" ||| ", spp1);
		string trg_rhs = line.substr(spp1, spp2 - spp1);

		// prob
		vector<float> v;
		spp1 = spp2 + 5;
		spp2 = line.size();
		istringstream iss(line.substr(spp1, spp2 - spp1).c_str());
		string w;

		while (iss >> w)
		{
			float p = atof(w.c_str());
			v.push_back(p);
		}

		pair<string, string> pr(trg_rhs, src_rhs);

		// update
		map<pair<string, string>, vector<float> >::iterator iter = m.find(pr);

		if (iter == m.end())
		{
			m.insert(map<pair<string, string>, vector<float> >::value_type(pr, v));
		}
		else
		{
			if (v[0] > iter->second[0])
			{
				iter->second[0] = v[0];
			}

			if (v[1] > iter->second[1])
			{
				iter->second[1] = v[1];
			}

			iter->second[2] += v[2];
		}

		// dump
		if (m.size() > max_capacity)
		{
			char fileName[100];
			sprintf(fileName, "r_ruleFreq_%d.txt", ++fileID);
			dump(m, fileName);
		}
	}

	// dump
	if (!m.empty())
	{
		char fileName[100];
		sprintf(fileName, "r_ruleFreq_%d.txt", ++fileID);
		dump(m, fileName);
	}

	return 0;
}
