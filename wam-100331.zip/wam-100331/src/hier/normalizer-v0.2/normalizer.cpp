#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <vector>

using namespace std;

/************************************************
  version
************************************************/
void version()
{
	cout << "----------------------------------------\n"
		    " normalizer v0.2\n"
			" 2010/03/03 - 2010/03/03\n"
			" (c) 2008-2010 Yang Liu\n"
			"----------------------------------------\n";
}

/************************************************
  dump
************************************************/
void dump(map<pair<string, string>, vector<float> >& m,
		  ofstream& out)
{
	float sum = 0;

	map<pair<string, string>, vector<float> >::iterator iter;

	for (iter = m.begin(); iter != m.end(); iter++)
	{
		sum += iter->second.back();
	}

	for (iter = m.begin(); iter != m.end(); iter++)
	{
		out << iter->first.first
			<< " ||| "
			<< iter->first.second
			<< " ||| "
			<< iter->second[0]
			<< " "
			<< iter->second[1]
			<< " "
			<< iter->second[2] / sum
			<< endl;
	}

	m.clear();
}

/************************************************
  main function
************************************************/
int main(int argc, char** argv)
{
	// version
	version();

	if (argc != 3)
	{
		cerr << "Usage: normalizer input output" << endl;
		exit(1);
	}

	ifstream in(argv[1]);
	ofstream out(argv[2]);
	map<pair<string, string>, vector<float> > m;
	string line,
		   lastStr;

	while (getline(in, line))
	{
		if (line.find("|||") == string::npos)
		{
			continue;
		}

		// source rhs
		int spp1 = 0,
			spp2 = line.find(" ||| ", spp1);
		string src_rhs = line.substr(spp1, spp2 - spp1);

		// right rhs
		spp1 = spp2 + 5;
		spp2 = line.find(" ||| ", spp1);
		string trg_rhs = line.substr(spp1, spp2 - spp1);

		// prob
		vector<float> v;
		spp1 = spp2 + 5;
		spp2 = line.size();
		istringstream iss(line.substr(spp1, spp2 - spp1).c_str());
		string w;

		while (iss >> w)
		{
			float p = atof(w.c_str());
			v.push_back(p);
		}

		pair<string, string> pr(src_rhs, trg_rhs);

		if (lastStr.empty())
		{
			m.insert(map<pair<string, string>, vector<float> >::value_type(pr, v));
			lastStr = src_rhs;
		}
		else
		{
			if (src_rhs == lastStr)
			{
				m.insert(map<pair<string, string>, vector<float> >::value_type(pr, v));
			}
			else
			{
				dump(m, out);
				m.insert(map<pair<string, string>, vector<float> >::value_type(pr, v));
				lastStr = src_rhs;
			}
		}
	}

	if (!m.empty())
	{
		dump(m, out);
	}

	return 0;
}
