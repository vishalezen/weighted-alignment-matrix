#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>

using namespace std;

/************************************************
  version
************************************************/
void version()
{
	cout << "----------------------------------------\n"
		    " merger v0.2\n"
			" 2010/03/03 - 2010/03/03\n"
			" (c) 2008-2010 Yang Liu\n"
			"----------------------------------------\n";
}

/************************************************
  main function
************************************************/
int main(int argc, char** argv)
{
	// version
	version();

	if (argc != 3)
	{
		cerr << "Usage: merger fileList merged" << endl;
		exit(1);
	}

	ifstream in(argv[1]);
	ofstream out(argv[2]);
	vector<ifstream*> ifstreamPtrVec;
	string line;

	while (getline(in, line))
	{
		ifstream* ptr = new ifstream;
		ptr->open(line.c_str());
		ifstreamPtrVec.push_back(ptr);
	}

	vector<string> lineVec(ifstreamPtrVec.size(), "");
	vector<int> getNextVec(ifstreamPtrVec.size(), 1);
	vector<int> finishVec(ifstreamPtrVec.size(), 0);
	vector<pair<string, string> > dataVec1(ifstreamPtrVec.size());
	vector<vector<float> > dataVec2(ifstreamPtrVec.size());

	while (1)
	{
		int i;

		for (i = 0; i < (int)getNextVec.size(); i++)
		{
			if (getNextVec[i] == 0)
			{
				continue;
			}

			if (getline(*ifstreamPtrVec[i], lineVec[i]))
			{
				string line = lineVec[i];

				// source right-hand side
				int spp1 = 0,
					spp2 = line.find(" ||| ", spp1);
				string src_rhs = line.substr(spp1, spp2 - spp1);

				// target right-hand side
				spp1 = spp2 + 5;
				spp2 = line.find(" ||| ", spp1);
				string trg_rhs = line.substr(spp1, spp2 - spp1);

				// prob
				spp1 = spp2 + 5;
				spp2 = line.size();
				vector<float> v;
				istringstream iss(line.substr(spp1, spp2 - spp1).c_str());
				string w;

				while (iss >> w)
				{
					float p = atof(w.c_str());
					v.push_back(p);
				}

				pair<string, string> pr(src_rhs, trg_rhs);
				dataVec1[i] = pr;
				dataVec2[i] = v;
			}
			else
			{
				finishVec[i] = 1;

				cout << "NO. "
					 << i + 1
					 << " file done!"
					 << endl;

				getNextVec[i] = 0;
			}
		}

		bool all_done = true;

		for (i = 0; i < (int)finishVec.size(); i++)
		{
			if (finishVec[i] == 0)
			{
				all_done = false;
				break;
			}
		}

		if (all_done)
		{
			break;
		}

		// minimum
		vector<int> minSctVec;

		for (i = 0; i < (int)dataVec1.size(); i++)
		{
			if (finishVec[i])
			{
				continue;
			}

			bool min = true;

			for (int j = 0; j < (int)dataVec1.size(); j++)
			{
				if (j == i ||
					finishVec[j])
				{
					continue;
				}

				if (dataVec1[j] < dataVec1[i])
				{
					min = false;
					break;
				}
			}

			if (min)
			{
				minSctVec.push_back(i);
			}
		}

		// lexical weights
		float lst = 0,
			  lts = 0,
			  freq = 0;

		for (i = 0; i < (int)minSctVec.size(); i++)
		{
			float temp_lst = dataVec2[minSctVec[i]][0],
				  temp_lts = dataVec2[minSctVec[i]][1],
				  temp_freq = dataVec2[minSctVec[i]][2];

			if (temp_lst > lst)
			{
				lst = temp_lst;
			}

			if (temp_lts > lts)
			{
				lts = temp_lts;
			}

			freq += temp_freq;
		}

		// dump
		out << dataVec1[minSctVec[0]].first
			<< " ||| "
			<< dataVec1[minSctVec[0]].second
			<< " ||| "
			<< lst
			<< " "
			<< lts
			<< " "
			<< freq
			<< endl;

		// update
		for (i = 0; i < (int)getNextVec.size(); i++)
		{
			getNextVec[i] = 0;
		}

		for (i = 0; i < (int)minSctVec.size(); i++)
		{
			getNextVec[minSctVec[i]] = 1;
		}
	}

	// avoid memory leak
	for (int i = 0; i < (int)ifstreamPtrVec.size(); i++)
	{
		delete ifstreamPtrVec[i];
	}

	return 0;
}
