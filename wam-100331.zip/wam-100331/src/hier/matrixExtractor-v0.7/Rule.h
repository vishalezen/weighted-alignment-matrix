#ifndef RULE_H
#define RULE_H

#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Rule
{
	// overload <<
	friend ostream& operator<<(ostream& out, const Rule& right);
public:
	/* member functions */
	// constructor
	Rule();
	// overload ==
	bool operator==(const Rule& right) const;
	// overload =
	Rule& operator=(const Rule& right);
	// overload <
	bool operator<(const Rule& right) const;
	// overload >
	bool operator>(const Rule& right) const;

	/* data members */
	vector<string> src_rhs;  // source right-hand side
	vector<string> trg_rhs;  // target right-hand side
};

#endif
