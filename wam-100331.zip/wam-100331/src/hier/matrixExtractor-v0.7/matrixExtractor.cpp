#include "Extract.h"

/************************************************
  version
************************************************/
void version()
{
	cout << "----------------------------------------\n"
		    " matrixExtractor v0.6\n"
			" 2009/09/17 - 2009/09/17\n"
			" (c) 2009 Yang Liu\n"
			"----------------------------------------\n";
}

/************************************************
  help
************************************************/
void help()
{
	cout << "Usage: matrixExtractor [-h] ...\n"
		    "Required arguments:\n"
			"  -s <src_file>   a file containing source sentences\n"
			"  -t <trg_file>   a file containing target sentences\n"
			"  -a <agt_file>   a file containing word alignments\n"
			"  -s2t <s2t_file> a file containing s2tTTable\n"
			"  -t2s <t2s_file> a file containing t2sTTable\n"
			"Optional arguments:\n"
			"  -c [1, +00)     maximal number of rules stored in memory (default: 1,000,000)\n"
			"  -p (0, 1)       pruning threshold (default: 0.1)\n"
			"  -h              prints this message to STDOUT\n";

	exit(1);
}

/************************************************
  main function
************************************************/
int main(int argc, char** argv)
{
	// version
	version();

	string srcFileName,
		   trgFileName,
		   agtFileName,
		   s2tFileName,
		   t2sFileName;
	float max_capacity = 1000000,
		  pruning_threshold = 0.1;

	for (int i = 1; i < argc; i++)
	{
		if ((string)argv[i] == "-s")
		{
			srcFileName = argv[++i];
		}
		else if ((string)argv[i] == "-t")
		{
			trgFileName = argv[++i];
		}
		else if ((string)argv[i] == "-a")
		{
			agtFileName = argv[++i];
		}
		else if ((string)argv[i] == "-s2t")
		{
			s2tFileName = argv[++i];
		}
		else if ((string)argv[i] == "-t2s")
		{
			t2sFileName = argv[++i];
		}
		else if ((string)argv[i] == "-c")
		{
			max_capacity = atof(argv[++i]);
		}
		else if ((string)argv[i] == "-p")
		{
			pruning_threshold = atof(argv[++i]);
		}
		else
		{
			help();
		}
	}

	if (srcFileName.empty() ||
		trgFileName.empty() ||
		agtFileName.empty() ||
		s2tFileName.empty() ||
		t2sFileName.empty())
	{
		help();
	}

	Extract e;
	e.extractFile(srcFileName.c_str(),
		          trgFileName.c_str(),
				  agtFileName.c_str(),
				  s2tFileName.c_str(),
				  t2sFileName.c_str(),
				  max_capacity,
				  pruning_threshold);

	return 0;
}
