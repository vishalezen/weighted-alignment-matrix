#ifndef MATRIX_H
#define MATRIX_H

#include <map>
#include <vector>

using namespace std;

class Matrix
{
public:
	/* member functions */
	// constructor
	Matrix();
	Matrix(const string& line);
	// check validity
	bool isValid(int srcSentLen,
		         int trgSentLen) const;
	// get target span
	void getTrgSpan(int src_begin,
		            int src_end,
					int& trg_begin,
					int& trg_end) const;
	// get sub alignment
	void getSubAlignment(int src_begin,
		                 int src_end,
						 int trg_begin,
						 int trg_end,
						 map<pair<int, int>, float>& a1,
						 map<pair<int, int>, float>& a2) const;
	void getSubAlignment(int src_begin,
		                 int src_end,
						 int trg_begin,
						 int trg_end,
						 int X1_src_begin,
						 int X1_src_end,
						 int X1_trg_begin,
						 int X1_trg_end,
						 map<pair<int, int>, float>& a1,
						 map<pair<int, int>, float>& a2) const;
	void getSubAlignment(int src_begin,
		                 int src_end,
						 int trg_begin,
						 int trg_end,
						 int X1_src_begin,
						 int X1_src_end,
						 int X1_trg_begin,
						 int X1_trg_end,
						 int X2_src_begin,
						 int X2_src_end,
						 int X2_trg_begin,
						 int X2_trg_end,
						 map<pair<int, int>, float>& a1,
						 map<pair<int, int>, float>& a2) const;
	// source side aligned?
	bool src_aligned(int src_pos) const;
	// target side aligned?
	bool trg_aligned(int trg_pos) const;
	// inside prob for zero variable
	float inside_zero(int src_begin,
		              int src_end,
					  int trg_begin,
					  int trg_end);
	// inside prob for one variable
	float inside_one(int src_begin,
		             int src_end,
					 int trg_begin,
					 int trg_end,
					 int X1_src_begin,
					 int X1_src_end,
					 int X1_trg_begin,
					 int X1_trg_end);
	// inside prob for two variables
	float inside_two(int src_begin,
		             int src_end,
					 int trg_begin,
					 int trg_end,
					 int X1_src_begin,
					 int X1_src_end,
					 int X1_trg_begin,
					 int X1_trg_end,
					 int X2_src_begin,
					 int X2_src_end,
					 int X2_trg_begin,
					 int X2_trg_end);
	// outside prob for zero variable
	float outside_zero(int src_begin,
		               int src_end,
					   int trg_begin,
					   int trg_end) const;
	// outside prob for one variable
	float outside_one(int src_begin,
		              int src_end,
					  int trg_begin,
					  int trg_end,
					  int X1_src_begin,
					  int X1_src_end,
					  int X1_trg_begin,
					  int X1_trg_end) const;
	// outside prob for two variables
	float outside_two(int src_begin,
		              int src_end,
					  int trg_begin,
					  int trg_end,
					  int X1_src_begin,
					  int X1_src_end,
					  int X1_trg_begin,
					  int X1_trg_end,
					  int X2_src_begin,
					  int X2_src_end,
					  int X2_trg_begin,
					  int X2_trg_end) const;
	// get point prob
	float getPointProb(int sp,
		               int tp) const;
	// get prob for the source range without gaps
	float getSrcRangeZeroGapProb(int tp,
		                         int src_begin,
								 int src_end) const;
	// get prob for the source range with one gap
	float getSrcRangeOneGapProb(int tp,
		                        int src_begin,
								int src_end,
								int X1_src_begin,
								int X1_src_end) const;
	// get prob for the source range with two gaps
	float getSrcRangeTwoGapsProb(int tp,
		                         int src_begin,
							 	 int src_end,
								 int X1_src_begin,
								 int X1_src_end,
								 int X2_src_begin,
								 int X2_src_end) const;
	// get prob for the target range without gaps
	float getTrgRangeZeroGapProb(int sp,
		                         int trg_begin,
								 int trg_end) const;
	// get prob for the target range with one gap
	float getTrgRangeOneGapProb(int sp,
		                        int trg_begin,
								int trg_end,
								int X1_trg_begin,
								int X1_trg_end) const;
	// get prob for the target range with two gaps
	float getTrgRangeTwoGapsProb(int sp,
		                         int trg_begin,
							 	 int trg_end,
								 int X1_trg_begin,
								 int X1_trg_end,
								 int X2_trg_begin,
								 int X2_trg_end) const;
	// show
	void show() const;

private:
	/* data members */
	map<pair<int, int>, float> matrix;  // matrix
	map<vector<int>, float> ipp_inside;  // matrix for inside prob
};

#endif
