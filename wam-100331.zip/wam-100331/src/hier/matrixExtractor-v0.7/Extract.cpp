#include <fstream>
#include <sstream>
#include <algorithm>
#include <ctime>
#include "Extract.h"

/************************************************
  constructor
************************************************/
Extract::Extract()
{
}

/************************************************
  extract from file
************************************************/
void Extract::extractFile(const char* srcFileName,
		                  const char* trgFileName,
					      const char* agtFileName,
					      const char* s2tFileName,
					      const char* t2sFileName,
					      float max_capacity,
						  float pruning_threshold)
{
	// read ttable files
	s2tTTable.readFile(s2tFileName);
	t2sTTable.readFile(t2sFileName);

	clock_t tb = clock();

	ifstream in1(srcFileName),
		     in2(trgFileName),
			 in3(agtFileName);
	string line1,
		   line2,
		   line3;
	map<Rule, vector<float> > ruleFreq;  // global rule freq
    int fileID = 0;     // file id
	float sentCount = 0, // sentence count
		  wordCount = 0;  // word count

	while (getline(in1, line1) &&
		   getline(in2, line2) &&
		   getline(in3, line3))
	{
		// get sentences
		vector<string> srcWordVec,
			           trgWordVec;
		buildWordVec(line1, srcWordVec);
		buildWordVec(line2, trgWordVec);

		wordCount += srcWordVec.size() + trgWordVec.size() - 2;

		// build matrices
		Matrix matrix(line3);

		// extract rules from a sentence pair
		map<Rule, vector<float> > rf;
		extractSent(srcWordVec, trgWordVec, matrix, rf, pruning_threshold);

		// update
		updateRuleFreq(rf, ruleFreq);

		cout << "("
			 << ++sentCount
			 << ") "
			 << rf.size()
			 << " "
			 << ruleFreq.size()
			 << endl;

		// dump
		if ((float)ruleFreq.size() >= max_capacity)
		{
			char fileName[100];
			sprintf(fileName, "ruleFreq_%d.txt", ++fileID);
			dump(ruleFreq, fileName);
		}
	}

	if (!ruleFreq.empty())
	{
		char fileName[100];
		sprintf(fileName, "ruleFreq_%d.txt", ++fileID);
		dump(ruleFreq, fileName);
	}

	clock_t te = clock();

	float elapsed_time = (float)(te - tb) / CLOCKS_PER_SEC;

	cout << "\n[SENT] "
		 << sentCount
		 << "\n[TIME] "
		 << elapsed_time
		 << "\n[SPEED] "
		 << wordCount / elapsed_time
		 << endl;
}

/************************************************
  extract rules from sentence
************************************************/
void Extract::extractSent(const vector<string>& srcWordVec,
		                  const vector<string>& trgWordVec,
					      Matrix& matrix,
					      map<Rule, vector<float> >& ruleFreq,
						  float threshold)
{
	// sentence lengths
	int srcSentLen = (int)srcWordVec.size() - 1,
		trgSentLen = (int)trgWordVec.size() - 1;

	// check validity
	if (!matrix.isValid(srcSentLen, trgSentLen))
	{
		return;
	}

	// raw rule freq
	map<vector<int>, map<Rule, vector<float> > > ruleMap;

	// zero variable
	zeroVariable(srcWordVec, trgWordVec, matrix, ruleMap, threshold);

	// one variable
	oneVariable(srcWordVec, trgWordVec, matrix, ruleMap, threshold);

	// two variables
	twoVariables(srcWordVec, trgWordVec, matrix, ruleMap, threshold);

	// get rule freq
	output(ruleMap, ruleFreq);
}

/************************************************
  build word vector
************************************************/
void Extract::buildWordVec(const string& line,
		                   vector<string>& wordVec)
{
	wordVec.clear();
	wordVec.push_back("$NULL");

	istringstream iss(line.c_str());
	string w;

	while (iss >> w)
	{
		wordVec.push_back(w);
	}
}

/************************************************
  zero variable
************************************************/
void Extract::zeroVariable(const vector<string>& srcWordVec,
		                   const vector<string>& trgWordVec,
					       Matrix& matrix,
					       map<vector<int>, map<Rule, vector<float> > >& ruleMap,
						   float threshold)
{
	int max_phrase_len = 10;  // maximal sentence length

	// enumerate all source spans
	for (int src_begin = 1; src_begin < (int)srcWordVec.size(); src_begin++)
	{
		// ignore if not aligned
		if (!matrix.src_aligned(src_begin))
		{
			continue;
		}

		for (int src_end = src_begin; src_end < (int)srcWordVec.size() && src_end - src_begin < max_phrase_len; src_end++)
		{
			// ignore if not aligned
			if (!matrix.src_aligned(src_end))
			{
				continue;
			}

			// get target span
			int begin = 0,
				end = 0;
			matrix.getTrgSpan(src_begin, src_end, begin, end);

			if (begin == 0 ||
				end == 0)
			{
				continue;
			}

			// source right-hand side
			vector<string> src_rhs;
			int i;

			for (i = src_begin; i <= src_end; i++)
			{
				src_rhs.push_back(srcWordVec[i]);
			}

			// target right-hand side
			vector<int> best_index;
			Rule best_rule;
			float best_lst = 0,
				  best_lts = 0,
				  best_freq = 0,
				  max_prob = 0;

			// target side boundary expansion
			for (int trg_begin = begin; trg_begin <= end; trg_begin++)
			{
				// ignore if not aligned
				if (!matrix.trg_aligned(trg_begin))
				{
					continue;
				}

				for (int trg_end = trg_begin; trg_end <= end && trg_end - trg_begin < max_phrase_len; trg_end++)
				{
					// ignore if not aligned
					if (!matrix.trg_aligned(trg_end))
					{
						continue;
					}

					// freq
					float freq = matrix.inside_zero(src_begin, src_end, trg_begin, trg_end) *
						         matrix.outside_zero(src_begin, src_end, trg_begin, trg_end);

					// pruning
					if (freq < threshold)
					{
						continue;
					}

					// alignment within the phrases
					map<pair<int, int>, float> a1, a2;
					matrix.getSubAlignment(src_begin, src_end, trg_begin, trg_end, a1, a2);

					// target right-hand side
					vector<string> trg_rhs;

					for (i = trg_begin; i <= trg_end; i++)
					{
						trg_rhs.push_back(trgWordVec[i]);
					}

					// lexical weights
					float lst = lexicalWeight(src_rhs, trg_rhs, a1, s2tTTable),
						  lts = lexicalWeight(trg_rhs, src_rhs, a2, t2sTTable);

					// get a new rule
					Rule rule;
					rule.src_rhs = src_rhs;
					rule.trg_rhs = trg_rhs;

					// span pair
					vector<int> spanPair;
					spanPair.push_back(src_begin);
					spanPair.push_back(src_end);
					spanPair.push_back(trg_begin);
					spanPair.push_back(trg_end);

					float p = lts + freq;

					if (p > max_prob)
					{
						best_index = spanPair;
						best_rule = rule;
						best_lst = lst;
						best_lts = lts;
						best_freq = freq;
						max_prob = p;
					}
				}
			}

            // only keep the best one
			if (max_prob > 0)
			{
				updateRuleMap(best_index, best_rule, best_lst, best_lts, best_freq, ruleMap);
			}
		}
	}
}

/************************************************
  one variable
************************************************/
void Extract::oneVariable(const vector<string>& srcWordVec,
		                  const vector<string>& trgWordVec,
					      Matrix& matrix,
					      map<vector<int>, map<Rule, vector<float> > >& ruleMap,
						  float threshold)
{
	// enumerate every inital phrase pair
	map<vector<int>, map<Rule, vector<float> > >::iterator iter1, iter2;

	for (iter1 = ruleMap.begin(); iter1 != ruleMap.end(); iter1++)
	{
		pair<int, int> src_span(iter1->first[0], iter1->first[1]),
			           trg_span(iter1->first[2], iter1->first[3]);

		// at least two words
		if (src_span.first == src_span.second)
		{
			continue;
		}

		// find sub phrases
		for (iter2 = ruleMap.begin(); iter2 != ruleMap.end(); iter2++)
		{
			// ignore itself
			if (iter2 == iter1)
			{
				continue;
			}

			pair<int, int> sub_src_span(iter2->first[0], iter2->first[1]),
				           sub_trg_span(iter2->first[2], iter2->first[3]);

			// sub-phrase?
			if (sub_src_span.first < src_span.first ||
				sub_src_span.second > src_span.second ||
				sub_trg_span.first < trg_span.first ||
				sub_trg_span.second > trg_span.second ||
				sub_src_span == src_span ||
				sub_trg_span == trg_span)
			{
				continue;
			}

			// length?
			if (src_span.second - src_span.first - sub_src_span.second + sub_src_span.first > 4)
			{
				continue;
			}

			// fractional count
			float freq = matrix.inside_one(src_span.first,
				                           src_span.second,
										   trg_span.first,
										   trg_span.second,
										   sub_src_span.first,
										   sub_src_span.second,
										   sub_trg_span.first,
										   sub_trg_span.second) *
						 matrix.outside_one(src_span.first,
				                            src_span.second,
										    trg_span.first,
										    trg_span.second,
										    sub_src_span.first,
										    sub_src_span.second,
										    sub_trg_span.first,
										    sub_trg_span.second);

			// pruning
			if (freq < threshold)
			{
				continue;
			}

			// source right-hand side
			vector<string> src_rhs;
			int i;

			for (i = src_span.first; i <= src_span.second; i++)
			{
				if (i < sub_src_span.first ||
					i > sub_src_span.second)
				{
					src_rhs.push_back(srcWordVec[i]);
				}
				else if (i == sub_src_span.first)
				{
					src_rhs.push_back("$X_1");
				}
			}

			// target right-hand side
			vector<string> trg_rhs;

			for (i = trg_span.first; i <= trg_span.second; i++)
			{
				if (i < sub_trg_span.first ||
					i > sub_trg_span.second)
				{
					trg_rhs.push_back(trgWordVec[i]);
				}
				else if (i == sub_trg_span.first)
				{
					trg_rhs.push_back("$X_1");
				}
			}

			// alignment
			map<pair<int, int>, float> a1,
				                       a2;
			matrix.getSubAlignment(src_span.first,
				                   src_span.second,
								   trg_span.first,
								   trg_span.second,
								   sub_src_span.first,
								   sub_src_span.second,
								   sub_trg_span.first,
								   sub_trg_span.second,
								   a1,
								   a2);

			// lexical weights
			float lst = lexicalWeight(src_rhs, trg_rhs, a1, s2tTTable),
				  lts = lexicalWeight(trg_rhs, src_rhs, a2, t2sTTable);

			// get a new rule
			Rule rule;
			rule.src_rhs = src_rhs;
			rule.trg_rhs = trg_rhs;

			// update
			updateRuleMap(iter1->first, rule, lst, lts, freq, ruleMap);
		}
	}
}

/************************************************
  two variables
************************************************/
void Extract::twoVariables(const vector<string>& srcWordVec,
		                   const vector<string>& trgWordVec,
					       Matrix& matrix,
					       map<vector<int>, map<Rule, vector<float> > >& ruleMap,
						   float threshold)
{
	// enumerate every initial phrase pair
	map<vector<int>, map<Rule, vector<float> > >::iterator iter1, iter2, iter3;

	for (iter1 = ruleMap.begin(); iter1 != ruleMap.end(); iter1++)
	{
		pair<int, int> src_span(iter1->first[0], iter1->first[1]),
			           trg_span(iter1->first[2], iter1->first[3]);

		// at least three words
		if (src_span.second - src_span.first < 2)
		{
			continue;
		}

		// find sub-phrase
		for (iter2 = ruleMap.begin(); iter2 != ruleMap.end(); iter2++)
		{
			// ignore itself
			if (iter2 == iter1)
			{
				continue;
			}

			pair<int, int> sub_src_span1(iter2->first[0], iter2->first[1]),
				           sub_trg_span1(iter2->first[2], iter2->first[3]);

			// sub-phrase?
			if (sub_src_span1.first < src_span.first ||
				sub_src_span1.second > src_span.second ||
				sub_trg_span1.first < trg_span.first ||
				sub_trg_span1.second > trg_span.second ||
				sub_src_span1 == src_span ||
				sub_trg_span1 == trg_span)
			{
				continue;
			}

			// the second varibal
			for (iter3 = ruleMap.begin(); iter3 != ruleMap.end(); iter3++)
			{
				// ignore itself
				if (iter3 == iter1 ||
					iter3 == iter2)
				{
					continue;
				}

				pair<int, int> sub_src_span2(iter3->first[0], iter3->first[1]),
					           sub_trg_span2(iter3->first[2], iter3->first[3]);

				// sub-phrase?
				if (sub_src_span2.first < src_span.first ||
					sub_src_span2.second > src_span.second ||
					sub_trg_span2.first < trg_span.first ||
					sub_trg_span2.second > trg_span.second ||
					sub_src_span2 == src_span ||
					sub_trg_span2 == trg_span)
				{
					continue;
                }
			
                // behind the first variable
				if (sub_src_span1.first >= sub_src_span2.first ||
					sub_src_span1.second >= sub_src_span2.first)
				{
					continue;
				}

				// no overlapping
				if ((sub_trg_span1.first - sub_trg_span2.second) *
					(sub_trg_span1.second - sub_trg_span2.first) <= 0)
				{
					continue;
				}

				// no adjacency
				if (sub_src_span1.second + 1 == sub_src_span2.first)
				{
					continue;
				}

				// length?
				if (src_span.second - src_span.first -
					sub_src_span1.second + sub_src_span1.first -
					sub_src_span2.second + sub_src_span2.first > 4)
				{
					continue;
				}

/*				cout << src_span.first 
				 << " " 
				 << src_span.second
				 << " "
				 << trg_span.first
				 << " "
				 << trg_span.second
				 << " ||| "
				 << sub_src_span1.first
				 << " "
				 << sub_src_span1.second
				 << " "
				 << sub_trg_span1.first
				 << " "
				 << sub_trg_span1.second
				 << " ||| "
				 << sub_src_span2.first
				 << " "
				 << sub_src_span2.second
				 << " "
				 << sub_trg_span2.first
				 << " "
				 << sub_trg_span2.second
				 << endl;
*/
				// fractional count
				float freq = matrix.inside_two(src_span.first,
					                           src_span.second,
											   trg_span.first,
											   trg_span.second,
											   sub_src_span1.first,
											   sub_src_span1.second,
											   sub_trg_span1.first,
											   sub_trg_span1.second,
											   sub_src_span2.first,
											   sub_src_span2.second,
											   sub_trg_span2.first,
											   sub_trg_span2.second) *
							 matrix.outside_two(src_span.first,
					                           src_span.second,
											   trg_span.first,
											   trg_span.second,
											   sub_src_span1.first,
											   sub_src_span1.second,
											   sub_trg_span1.first,
											   sub_trg_span1.second,
											   sub_src_span2.first,
											   sub_src_span2.second,
											   sub_trg_span2.first,
											   sub_trg_span2.second);

				// pruning
				if (freq < threshold)
				{
					continue;
				}

				// source right-hand side
				vector<string> src_rhs;
				int i;

				for (i = src_span.first; i <= src_span.second; i++)
				{
					if (i >= sub_src_span1.first &&
						i <= sub_src_span1.second)
					{
						if (i == sub_src_span1.first)
						{
							src_rhs.push_back("$X_1");
						}
					}
					else if (i >= sub_src_span2.first &&
						     i <= sub_src_span2.second)
					{
						if (i == sub_src_span2.first)
						{
							src_rhs.push_back("$X_2");
						}
					}
					else
					{
						src_rhs.push_back(srcWordVec[i]);
					}
				}

				// target right-hand side
				vector<string> trg_rhs;

				for (i = trg_span.first; i <= trg_span.second; i++)
				{
					if (i >= sub_trg_span1.first &&
						i <= sub_trg_span1.second)
					{
						if (i == sub_trg_span1.first)
						{
							trg_rhs.push_back("$X_1");
						}
					}
					else if (i >= sub_trg_span2.first &&
						     i <= sub_trg_span2.second)
					{
						if (i == sub_trg_span2.first)
						{
							trg_rhs.push_back("$X_2");
						}
					}
					else
					{
						trg_rhs.push_back(trgWordVec[i]);
					}
				}

				// alignments
				map<pair<int, int>, float> a1,
										   a2;
				matrix.getSubAlignment(src_span.first,
									   src_span.second,
									   trg_span.first,
									   trg_span.second,
									   sub_src_span1.first,
									   sub_src_span1.second,
									   sub_trg_span1.first,
									   sub_trg_span1.second,
									   sub_src_span2.first,
									   sub_src_span2.second,
									   sub_trg_span2.first,
									   sub_trg_span2.second,
									   a1,
									   a2);

				// lexical weights
				float lst = lexicalWeight(src_rhs, trg_rhs, a1, s2tTTable),
					  lts = lexicalWeight(trg_rhs, src_rhs, a2, t2sTTable);

				// get a new rule
				Rule rule;
				rule.src_rhs = src_rhs;
				rule.trg_rhs = trg_rhs;

				// update rule map
				updateRuleMap(iter1->first, rule, lst, lts, freq, ruleMap);
			}
		}
	}
}

/************************************************
  calculate lexical weight
************************************************/
float Extract::lexicalWeight(const vector<string>& src_rhs,
		                     const vector<string>& trg_rhs,
					     	 const map<pair<int, int>, float>& alignment,
						     const TTable& tTable)
{
	if (0)
	{
		int i;

		for (i = 0; i < (int)src_rhs.size(); i++)
		{
			cout << src_rhs[i] << " ";
		}

		cout << "||| ";

		for (i = 0; i < (int)trg_rhs.size(); i++)
		{
			cout << trg_rhs[i] << " ";
		}

		cout << "||| ";

		map<pair<int, int>, float>::const_iterator iter;

		for (iter = alignment.begin(); iter != alignment.end(); iter++)
		{
			cout << iter->first.first
				 << ":"
				 << iter->first.second
				 << "/"
				 << iter->second
				 << " ";
		}

		cout << endl;
	}

	float lw = 1.0;

	// every target word
	for (int i = 0; i < (int)trg_rhs.size(); i++)
	{
		// ignore variable
		if (trg_rhs[i].find("$X") != string::npos)
		{
			continue;
		}

		float sum = 0,  // sum
			  p_aligned_to_null = 1.0;  // prob that aligned to null
		int count = 0;  // number of links

		map<pair<int, int>, float>::const_iterator iter;

		for (iter = alignment.begin(); iter != alignment.end(); iter++)
		{
			if (iter->first.second == i + 1)
			{
				count++;
				float prob = tTable.getProb(src_rhs[iter->first.first - 1], trg_rhs[i]);
				sum += prob * iter->second;
				p_aligned_to_null *= 1.0 - iter->second;
			}
		}

		float prob = tTable.getProb("$NULL", trg_rhs[i]);

		if (count > 0)
		{
			lw *= sum / count + prob * p_aligned_to_null;
		}
		else
		{
			lw *= prob * p_aligned_to_null;
		}
	}

	return lw;
}

/************************************************
  update rule map
************************************************/
void Extract::updateRuleMap(const vector<int>& spanPair,
							const Rule& rule,
		                    float lst,
					        float lts,
					        float freq,
					        map<vector<int>, map<Rule, vector<float> > >& ruleMap)
{
	map<vector<int>, map<Rule, vector<float> > >::iterator iter1 = ruleMap.find(spanPair);

	if (iter1 == ruleMap.end())
	{
		vector<float> v;
		v.push_back(lst);
		v.push_back(lts);
		v.push_back(freq);

		map<Rule, vector<float> > m;
		m.insert(map<Rule, vector<float> >::value_type(rule, v));

		ruleMap.insert(map<vector<int>, map<Rule, vector<float> > >::value_type(spanPair, m));
	}
	else
	{
		map<Rule, vector<float> >::iterator iter2 = iter1->second.find(rule);

		if (iter2 == iter1->second.end())
		{
			vector<float> v;
			v.push_back(lst);
			v.push_back(lts);
			v.push_back(freq);

			iter1->second.insert(map<Rule, vector<float> >::value_type(rule, v));
		}
		else
		{
			if (lst > iter2->second[0])
			{
				iter2->second[0] = lst;
			}

			if (lts > iter2->second[1])
			{
				iter2->second[1] = lts;
			}

			iter2->second[2] += freq;
		}
	}
}

/************************************************
  show rule map
************************************************/
void Extract::showRuleMap(const map<vector<int>, map<Rule, vector<float> > >& ruleMap)
{
	map<vector<int>, map<Rule, vector<float> > >::const_iterator iter1;

	for (iter1 = ruleMap.begin(); iter1 != ruleMap.end(); iter1++)
	{
		cout << "\n["
			 << iter1->first[0]
			 << ", "
			 << iter1->first[1]
			 << "] - ["
			 << iter1->first[2]
			 << ", "
			 << iter1->first[3]
			 << "] "
			 << iter1->second.size()
			 << endl;

		map<Rule, vector<float> >::const_iterator iter2;
		int count = 0;

		for (iter2 = iter1->second.begin(); iter2 != iter1->second.end(); iter2++)
		{
			cout << "("	
				 << ++count
				 << ") "
				 << iter2->first
				 << " ||| "
				 << iter2->second[0]
				 << " "
				 << iter2->second[1]
				 << " "
				 << iter2->second[2]
				 << endl;
		}
	}
}

/************************************************
  output rule freq
************************************************/
void Extract::output(map<vector<int>, map<Rule, vector<float> > >& ruleMap,
		             map<Rule, vector<float> >& ruleFreq)
{
	map<vector<int>, map<Rule, vector<float> > >::iterator iter;

	for (iter = ruleMap.begin(); iter != ruleMap.end(); iter++)
	{
		updateRuleFreq(iter->second, ruleFreq);
	}
}

/************************************************
  update
************************************************/
void Extract::updateRuleFreq(const map<Rule, vector<float> >& m1,
		                     map<Rule, vector<float> >& m2)
{
	map<Rule, vector<float> >::const_iterator iter;

	for (iter = m1.begin(); iter != m1.end(); iter++)
	{
		updateRuleFreq(iter->first, iter->second, m2);
	}
}

void Extract::updateRuleFreq(const Rule& rule,
		                     const vector<float>& v,
					    	 map<Rule, vector<float> >& m)
{
	map<Rule, vector<float> >::iterator iter = m.find(rule);
	
	if (iter == m.end())
	{
		m.insert(map<Rule, vector<float> >::value_type(rule, v));
	}
	else
	{
		if (v[0] > iter->second[0])
		{
			iter->second[0] = v[0];
		}

		if (v[1] > iter->second[1])
		{
			iter->second[1] = v[1];
		}

		iter->second[2] += v[2];
	}
}

/************************************************
  dump
************************************************/
void Extract::dump(map<Rule, vector<float> >& m,
		           const char* fileName)
{
	ofstream out(fileName);

	map<Rule, vector<float> >::iterator iter;

	for (iter = m.begin(); iter != m.end(); iter++)
	{
		out << iter->first
			<< " ||| "
			<< iter->second[0]
			<< " "
			<< iter->second[1]
			<< " "
			<< iter->second[2]
			<< endl;
	}

	m.clear();
}
