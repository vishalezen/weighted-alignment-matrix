#include <iostream>
#include <fstream>
#include <sstream>
#include <ctime>
#include "TTable.h"

/************************************************
  constructor
************************************************/
TTable::TTable()
{
}

/************************************************
  read file
************************************************/
void TTable::readFile(const char* fileName)
{
	cout << "Read translation probability table file \""
		 << fileName
		 << "\" ... ";

	clock_t tb = clock();

	ifstream in(fileName);
	string line;

	while (getline(in, line))
	{
		istringstream iss(line.c_str());
		string srcWord, trgWord, probStr;
		iss >> srcWord >> trgWord >> probStr;
		float prob = atof(probStr.c_str());
		pair<string, string> pr(srcWord, trgWord);
		tTable.insert(map<pair<string, string>, float>::value_type(pr, prob));
	}

	clock_t te = clock();

	cout << tTable.size()
		 << " entries loaded in "
		 << (float)(te - tb) / CLOCKS_PER_SEC
		 << " seconds"
		 << endl;
}

/************************************************
  write file
************************************************/
void TTable::writeFile(const char* fileName)
{
	ofstream out(fileName);

	map<pair<string, string>, float>::iterator iter;

	for (iter = tTable.begin(); iter != tTable.end(); iter++)
	{
		out << iter->first.first
			<< " "
			<< iter->first.second
			<< " "
			<< iter->second
			<< endl;
	}
}

/************************************************
  get probability
************************************************/
float TTable::getProb(const string& srcWord,
		              const string& trgWord) const
{
	pair<string, string> pr(srcWord, trgWord);

	map<pair<string, string>, float>::const_iterator iter = tTable.find(pr);

	if (iter == tTable.end())
	{
		return (float)1e-7;
	}
	else
	{
		return iter->second;
	}
}
