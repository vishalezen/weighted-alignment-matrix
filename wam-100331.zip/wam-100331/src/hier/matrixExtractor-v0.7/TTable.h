#ifndef TTABLE_H
#define TTABLE_H

#include <map>
#include <string>

using namespace std;

class TTable
{
public:
	/* member functions */
	// constructor
	TTable();
	// read file
	void readFile(const char* fileName);
	// write file
	void writeFile(const char* fileName);
	// get prob
	float getProb(const string& srcWord,
		          const string& trgWord) const;

	/* data members */
	map<pair<string, string>, float> tTable;  // ttable
};

#endif
