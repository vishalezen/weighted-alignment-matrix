#include "Rule.h"

/************************************************
  constructor
************************************************/
Rule::Rule()
{
}

/************************************************
  overload <<
************************************************/
ostream& operator<<(ostream& out, const Rule& right)
{
	int i;

	for (i = 0; i < (int)right.src_rhs.size(); i++)
	{
		out << right.src_rhs[i]
			<< " ";
	}

	out << "||| ";

	for (i = 0; i < (int)right.trg_rhs.size(); i++)
	{
		out << right.trg_rhs[i];

		if (i != (int)right.trg_rhs.size() - 1)
		{
			out << " ";
		}
	}

	return out;
}

/************************************************
  overload ==
************************************************/
bool Rule::operator==(const Rule& right) const
{
	if (src_rhs == right.src_rhs &&
		trg_rhs == right.trg_rhs)
	{
		return true;
	}

	return false;
}

/************************************************
  overload =
************************************************/
Rule& Rule::operator=(const Rule& right)
{
	if (this != &right)
	{
		src_rhs = right.src_rhs;
		trg_rhs = right.trg_rhs;
	}

	return *this;
}

/************************************************
  overload <
************************************************/
bool Rule::operator<(const Rule& right) const
{
	if (src_rhs < right.src_rhs)
	{
		return true;
	}
	else if (src_rhs == right.src_rhs)
	{
		if (trg_rhs < right.trg_rhs)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	else
	{
		return false;
	}
}

/************************************************
  overload >
************************************************/
bool Rule::operator>(const Rule& right) const
{
	if (src_rhs > right.src_rhs)
	{
		return true;
	}
	else if (src_rhs == right.src_rhs)
	{
		if (trg_rhs > right.trg_rhs)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	else
	{
		return false;
	}
}
