#include <iostream>
#include <sstream>
#include <string>
#include "Matrix.h"

/************************************************
  constructor
************************************************/
Matrix::Matrix()
{
}

Matrix::Matrix(const string& line)
{
	istringstream iss(line.c_str());
	string w;

	while (iss >> w)
	{
		int spp1 = w.find(':'),
			spp2 = w.find('/'),
			sp = atoi(w.substr(0, spp1).c_str()),
			tp = atoi(w.substr(spp1 + 1, spp2 - spp1 - 1).c_str());
		float prob = atof(w.substr(spp2 + 1, (int)w.size() - spp2 - 1).c_str());
		matrix.insert(map<pair<int, int>, float>::value_type(pair<int, int>(sp, tp), prob));
	}
}

/************************************************
  show
************************************************/
void Matrix::show() const
{
	map<pair<int, int>, float>::const_iterator iter;

	for (iter = matrix.begin(); iter != matrix.end(); iter++)
	{
		cout << iter->first.first
			 << ":"
			 << iter->first.second
			 << "/"
			 << iter->second
			 << " ";
	}

	cout << endl;
}

/************************************************
  inside prob for zero variable
************************************************/
float Matrix::inside_zero(int src_begin,
		                  int src_end,
				    	  int trg_begin,
					      int trg_end)
{
	// source and target spans
	vector<int> v;
	v.push_back(src_begin);
	v.push_back(src_end);
	v.push_back(trg_begin);
	v.push_back(trg_end);

	map<vector<int>, float>::iterator iter = ipp_inside.find(v);

	if (iter != ipp_inside.end())
	{
		return iter->second;
	}
	
	// inside prob
	float prob = 1.0;

	if (src_begin == src_end &&
		trg_begin == trg_end)
	{
		prob = getPointProb(src_begin, trg_begin);
	}
	else if (src_begin < src_end &&
		     trg_begin == trg_end)
	{
		prob = getPointProb(src_begin, trg_begin) *
			   getPointProb(src_end, trg_begin);
	}
	else if (src_begin == src_end &&
		     trg_begin < trg_end)
	{
		prob = getPointProb(src_begin, trg_begin) *
			   getPointProb(src_begin, trg_end);
	}
	else
	{
		float p1 = (1.0 - getPointProb(src_begin, trg_begin)) *
			       (1.0 - getPointProb(src_begin, trg_end)) *
				   (1.0 - getPointProb(src_end, trg_begin)) *
				   (1.0 - getPointProb(src_end, trg_end)) *
				   getSrcRangeZeroGapProb(trg_begin, src_begin, src_end) *
				   getSrcRangeZeroGapProb(trg_end, src_begin, src_end) *
				   getTrgRangeZeroGapProb(src_begin, trg_begin, trg_end) *
				   getTrgRangeZeroGapProb(src_end, trg_begin, trg_end);

		float p2 = getPointProb(src_begin, trg_end) * 
			       (1.0 - getPointProb(src_begin, trg_begin)) *
				   (1.0 - getPointProb(src_end, trg_begin)) *
				   (1.0 - getPointProb(src_end, trg_end)) *
				   getSrcRangeZeroGapProb(trg_begin, src_begin, src_end) *
				   getTrgRangeZeroGapProb(src_end, trg_begin, trg_end);

		float p3 = getPointProb(src_begin, trg_begin) * 
			       (1.0 - getPointProb(src_begin, trg_end)) *
				   (1.0 - getPointProb(src_end, trg_begin)) *
				   (1.0 - getPointProb(src_end, trg_end)) *
				   getSrcRangeZeroGapProb(trg_end, src_begin, src_end) *
				   getTrgRangeZeroGapProb(src_end, trg_begin, trg_end);

		float p4 = getPointProb(src_end, trg_begin) * 
			       (1.0 - getPointProb(src_begin, trg_end)) *
				   (1.0 - getPointProb(src_begin, trg_begin)) *
				   (1.0 - getPointProb(src_end, trg_end)) *
				   getSrcRangeZeroGapProb(trg_end, src_begin, src_end) *
				   getTrgRangeZeroGapProb(src_begin, trg_begin, trg_end);

		float p5 = getPointProb(src_end, trg_end) * 
			       (1.0 - getPointProb(src_begin, trg_end)) *
				   (1.0 - getPointProb(src_begin, trg_begin)) *
				   (1.0 - getPointProb(src_end, trg_begin)) *
				   getSrcRangeZeroGapProb(trg_begin, src_begin, src_end) *
				   getTrgRangeZeroGapProb(src_begin, trg_begin, trg_end);

		float p6 = getPointProb(src_begin, trg_end) *
			       getPointProb(src_end, trg_begin) *
				   (1.0 - getPointProb(src_begin, trg_begin)) *
				   (1.0 - getPointProb(src_end, trg_end));

		float p7 = getPointProb(src_begin, trg_begin) *
			       getPointProb(src_end, trg_end) *
				   (1.0 - getPointProb(src_begin, trg_end)) *
				   (1.0 - getPointProb(src_end, trg_begin));

		float p8 = getPointProb(src_begin, trg_begin) *
			       getPointProb(src_begin, trg_end) *
				   (1.0 - getPointProb(src_end, trg_begin)) *
				   (1.0 - getPointProb(src_end, trg_end)) *
				   getTrgRangeZeroGapProb(src_end, trg_begin, trg_end);

		float p9 = getPointProb(src_begin, trg_begin) *
			       getPointProb(src_end, trg_begin) *
				   (1.0 - getPointProb(src_begin, trg_end)) *
				   (1.0 - getPointProb(src_end, trg_end)) *
				   getSrcRangeZeroGapProb(trg_end, src_begin, src_end);

		float p10 = getPointProb(src_end, trg_begin) *
			        getPointProb(src_end, trg_end) *
				    (1.0 - getPointProb(src_begin, trg_begin)) *
				    (1.0 - getPointProb(src_begin, trg_end)) *
				    getTrgRangeZeroGapProb(src_begin, trg_begin, trg_end);

		float p11 = getPointProb(src_begin, trg_end) *
			        getPointProb(src_end, trg_end) *
				    (1.0 - getPointProb(src_begin, trg_begin)) *
				    (1.0 - getPointProb(src_end, trg_begin)) *
				    getSrcRangeZeroGapProb(trg_begin, src_begin, src_end);

		float p12 = getPointProb(src_begin, trg_begin) *
			        getPointProb(src_end, trg_begin) *
				    getPointProb(src_end, trg_end) *
				    (1.0 - getPointProb(src_begin, trg_end));

		float p13 = (1.0 - getPointProb(src_begin, trg_begin)) *
			        getPointProb(src_end, trg_begin) *
				    getPointProb(src_end, trg_end) *
				    getPointProb(src_begin, trg_end);

		float p14 = getPointProb(src_begin, trg_begin) *
			        (1.0 - getPointProb(src_end, trg_begin)) *
				    getPointProb(src_end, trg_end) *
				    getPointProb(src_begin, trg_end);

		float p15 = getPointProb(src_begin, trg_begin) *
			        getPointProb(src_end, trg_begin) *
				    (1.0 - getPointProb(src_end, trg_end)) *
				    getPointProb(src_begin, trg_end);

		float p16 = getPointProb(src_begin, trg_begin) *
			        getPointProb(src_end, trg_begin) *
				    getPointProb(src_end, trg_end) *
				    getPointProb(src_begin, trg_end);

		prob = p1 + p2 + p3 + p4 + p5 + p6 + p7 + p8 +
			   p9 + p10 + p11 + p12 + p13 + p14 + p15 + p16;
	}

	ipp_inside.insert(map<vector<int>, float>::value_type(v, prob));

	return prob;
}

/************************************************
  inside prob for one variable
************************************************/
float Matrix::inside_one(int src_begin,
		                 int src_end,
				    	 int trg_begin,
					     int trg_end,
		    			 int X1_src_begin,
			    		 int X1_src_end,
				    	 int X1_trg_begin,
					     int X1_trg_end)
{
	// inside zero
	float X1_inside_prob = inside_zero(X1_src_begin,
		                               X1_src_end,
									   X1_trg_begin,
									   X1_trg_end);

	float prob = 1.0; 

	if (X1_src_begin > src_begin &&
		X1_src_end < src_end &&
		X1_trg_begin > trg_begin &&
		X1_trg_end < trg_end)
	{
		float p1 = (1.0 - getPointProb(src_begin, trg_begin)) *
			       (1.0 - getPointProb(src_begin, trg_end)) *
				   (1.0 - getPointProb(src_end, trg_begin)) *
				   (1.0 - getPointProb(src_end, trg_end)) *
				   getSrcRangeOneGapProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end) *
				   getSrcRangeOneGapProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end) *
				   getTrgRangeOneGapProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end) *
				   getTrgRangeOneGapProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end);

		float p2 = getPointProb(src_begin, trg_end) *
			       (1.0 - getPointProb(src_begin, trg_begin)) *
				   (1.0 - getPointProb(src_end, trg_begin)) *
				   (1.0 - getPointProb(src_end, trg_end)) *
				   getSrcRangeOneGapProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end) *
				   getTrgRangeOneGapProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end);

		float p3 = (1.0 - getPointProb(src_begin, trg_end)) *
			       getPointProb(src_begin, trg_begin) *
				   (1.0 - getPointProb(src_end, trg_begin)) *
				   (1.0 - getPointProb(src_end, trg_end)) *
				   getSrcRangeOneGapProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end) *
				   getTrgRangeOneGapProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end);

		float p4 = (1.0 - getPointProb(src_begin, trg_end)) *
			       (1.0 - getPointProb(src_begin, trg_begin)) *
				   getPointProb(src_end, trg_begin) *
				   (1.0 - getPointProb(src_end, trg_end)) *
				   getSrcRangeOneGapProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end) *
				   getTrgRangeOneGapProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end);

		float p5 = (1.0 - getPointProb(src_begin, trg_end)) *
			       (1.0 - getPointProb(src_begin, trg_begin)) *
				   (1.0 - getPointProb(src_end, trg_begin)) *
				   getPointProb(src_end, trg_end) *
				   getSrcRangeOneGapProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end) *
				   getTrgRangeOneGapProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end);

		float p6 = getPointProb(src_begin, trg_end) *
			       (1.0 - getPointProb(src_begin, trg_begin)) *
				   getPointProb(src_end, trg_begin) *
				   (1.0 - getPointProb(src_end, trg_end));

		float p7 = (1.0 - getPointProb(src_begin, trg_end)) *
			       getPointProb(src_begin, trg_begin) *
				   (1.0 - getPointProb(src_end, trg_begin)) *
				   getPointProb(src_end, trg_end);

		float p8 = getPointProb(src_begin, trg_end) *
			       getPointProb(src_begin, trg_begin) *
				   (1.0 - getPointProb(src_end, trg_begin)) *
				   (1.0 - getPointProb(src_end, trg_end)) *
				   getTrgRangeOneGapProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end);

		float p9 = (1.0 - getPointProb(src_begin, trg_end)) *
			       getPointProb(src_begin, trg_begin) *
				   getPointProb(src_end, trg_begin) *
				   (1.0 - getPointProb(src_end, trg_end)) *
				   getSrcRangeOneGapProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end);

		float p10 = (1.0 - getPointProb(src_begin, trg_end)) *
			        (1.0 - getPointProb(src_begin, trg_begin)) *
				    getPointProb(src_end, trg_begin) *
				    getPointProb(src_end, trg_end) *
				    getTrgRangeOneGapProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end);

		float p11 = getPointProb(src_begin, trg_end) *
			        (1.0 - getPointProb(src_begin, trg_begin)) *
				    (1.0 - getPointProb(src_end, trg_begin)) *
				    getPointProb(src_end, trg_end) *
				    getSrcRangeOneGapProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end);

		float p12 = (1.0 - getPointProb(src_begin, trg_end)) *
			        getPointProb(src_begin, trg_begin) *
				    getPointProb(src_end, trg_begin) *
				    getPointProb(src_end, trg_end);

		float p13 = getPointProb(src_begin, trg_end) *
			        (1.0 - getPointProb(src_begin, trg_begin)) *
				    getPointProb(src_end, trg_begin) *
				    getPointProb(src_end, trg_end);

		float p14 = getPointProb(src_begin, trg_end) *
			        getPointProb(src_begin, trg_begin) *
				    (1.0 - getPointProb(src_end, trg_begin)) *
				    getPointProb(src_end, trg_end);

		float p15 = getPointProb(src_begin, trg_end) *
			        getPointProb(src_begin, trg_begin) *
				    getPointProb(src_end, trg_begin) *
				    (1.0 - getPointProb(src_end, trg_end));

		float p16 = getPointProb(src_begin, trg_end) *
			        getPointProb(src_begin, trg_begin) *
				    getPointProb(src_end, trg_begin) *
				    getPointProb(src_end, trg_end);

		prob = p1 + p2 + p3 + p4 + p5 + p6 + p7 + p8 +
			   p9 + p10 + p11 + p12 + p13 + p14 + p15 + p16;
	}
	else if (X1_src_begin == src_begin &&
		     X1_src_end < src_end &&
			 X1_trg_begin > trg_begin &&
			 X1_trg_end < trg_end)
	{
		float p1 = (1.0 - getPointProb(src_end, trg_begin)) *
			       (1.0 - getPointProb(src_end, trg_end)) *
				   getSrcRangeOneGapProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end) *
				   getSrcRangeOneGapProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end) *
				   getTrgRangeOneGapProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end);

		float p2 = getPointProb(src_end, trg_begin) * 
			       (1.0 - getPointProb(src_end, trg_end)) *
				   getSrcRangeOneGapProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end);

		float p3 = (1.0 - getPointProb(src_end, trg_begin)) *
			       getPointProb(src_end, trg_end) *
				   getSrcRangeOneGapProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end);

		float p4 = getPointProb(src_end, trg_begin) *
			       getPointProb(src_end, trg_end);

		prob = p1 + p2 + p3 + p4;
		
	}
	else if (X1_src_begin > src_begin &&
		     X1_src_end < src_end &&
			 X1_trg_begin == trg_begin &&
			 X1_trg_end < trg_end)
	{
		float p1 = (1.0 - getPointProb(src_begin, trg_end)) *
			       (1.0 - getPointProb(src_end, trg_end)) *
				   getTrgRangeOneGapProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end) *
				   getTrgRangeOneGapProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end) *
				   getSrcRangeOneGapProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end);

		float p2 = getPointProb(src_begin, trg_end) *
			       (1.0 - getPointProb(src_end, trg_end)) *
				   getTrgRangeOneGapProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end);

		float p3 = (1.0 - getPointProb(src_begin, trg_end)) *
			       getPointProb(src_end, trg_end) *
				   getTrgRangeOneGapProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end);

		float p4 = getPointProb(src_begin, trg_end) *
			       getPointProb(src_end, trg_end);

		prob = p1 + p2 + p3 + p4;
	}
	else if (X1_src_begin > src_begin &&
		     X1_src_end == src_end &&
			 X1_trg_begin > trg_begin &&
			 X1_trg_end < trg_end)
	{
		float p1 = (1.0 - getPointProb(src_begin, trg_begin)) *
			       (1.0 - getPointProb(src_begin, trg_end)) *
				   getSrcRangeOneGapProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end) *
				   getSrcRangeOneGapProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end) *
				   getTrgRangeOneGapProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end);

		float p2 = getPointProb(src_begin, trg_begin) *
			       (1.0 - getPointProb(src_begin, trg_end)) *
				   getSrcRangeOneGapProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end);

		float p3 = (1.0 - getPointProb(src_begin, trg_begin)) *
			       getPointProb(src_begin, trg_end) *
				   getSrcRangeOneGapProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end);

		float p4 = getPointProb(src_begin, trg_begin) *
			       getPointProb(src_begin, trg_end);

		prob = p1 + p2 + p3 + p4;
	}
	else if (X1_src_begin > src_begin &&
		     X1_src_end < src_end &&
			 X1_trg_begin > trg_begin &&
			 X1_trg_end == trg_end)
	{
		float p1 = (1.0 - getPointProb(src_begin, trg_begin)) *
			       (1.0 - getPointProb(src_end, trg_begin)) *
				   getTrgRangeOneGapProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end) *
				   getTrgRangeOneGapProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end) *
				   getSrcRangeOneGapProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end);

		float p2 = getPointProb(src_begin, trg_begin) *
			       (1.0 - getPointProb(src_end, trg_begin)) *
				   getTrgRangeOneGapProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end);

		float p3 = (1.0 - getPointProb(src_begin, trg_begin)) *
			       getPointProb(src_end, trg_begin) *
				   getTrgRangeOneGapProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end);

		float p4 = getPointProb(src_begin, trg_begin) *
			       getPointProb(src_end, trg_begin);

		prob = p1 + p2 + p3 + p4;
	}
	else if (X1_src_begin == src_begin &&
		     X1_src_end < src_end &&
			 X1_trg_begin > trg_begin &&
			 X1_trg_end == trg_end)
	{
		float p1 = (1.0 - getPointProb(src_end, trg_begin)) * 
			       getSrcRangeOneGapProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end) *
				   getTrgRangeOneGapProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end);

		float p2 = getPointProb(src_end, trg_begin);

		prob = p1 + p2;
	}
	else if (X1_src_begin == src_begin &&
		     X1_src_end < src_end &&
			 X1_trg_begin == trg_begin &&
			 X1_trg_end < trg_end)
	{
		float p1 = (1.0 - getPointProb(src_end, trg_end)) *
			       getSrcRangeOneGapProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end) *
				   getTrgRangeOneGapProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end);

		float p2 = getPointProb(src_end, trg_end);

		prob = p1 + p2;
	}
	else if (X1_src_begin > src_begin &&
		     X1_src_end == src_end &&
			 X1_trg_begin == trg_begin &&
			 X1_trg_end < trg_end)
	{
		float p1 = (1.0 - getPointProb(src_begin, trg_end)) *
			       getSrcRangeOneGapProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end) *
				   getTrgRangeOneGapProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end);

		float p2 = getPointProb(src_begin, trg_end);

		prob = p1 + p2;
	}
	else if (X1_src_begin > src_begin &&
		     X1_src_end == src_end &&
			 X1_trg_begin > trg_begin &&
			 X1_trg_end == trg_end)
	{
		float p1 = (1.0 - getPointProb(src_begin, trg_begin)) *
			       getSrcRangeOneGapProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end) *
				   getTrgRangeOneGapProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end);

		float p2 = getPointProb(src_begin, trg_begin);

		prob = p1 + p2;
	}
	else
	{
		cerr << "\nERROR at [Matrix::inside_one]: "
			 << "it is impossible to get here!\n"
			 << "["
			 << src_begin
			 << ", "
			 << src_end
			 << ", "
			 << trg_begin
			 << ", "
			 << trg_end
			 << "] -> ["
			 << X1_src_begin
			 << ", "
			 << X1_src_end
			 << ", "
			 << X1_trg_begin
			 << ", "
			 << X1_trg_end
			 << "] "
			 << endl;

		exit(1);
	}

	return X1_inside_prob * prob;
}

/************************************************
  inside prob for two variables
************************************************/
float Matrix::inside_two(int src_begin,
		                 int src_end,
				    	 int trg_begin,
					     int trg_end,
				    	 int X1_src_begin,
		    			 int X1_src_end,
			    		 int X1_trg_begin,
				    	 int X1_trg_end,
    					 int X2_src_begin,
	    				 int X2_src_end,
		    			 int X2_trg_begin,
			    		 int X2_trg_end)
{
	// inside prob for zero variables
	float X1_inside_prob = inside_zero(X1_src_begin,
		                               X1_src_end,
									   X1_trg_begin,
									   X1_trg_end),
		  X2_inside_prob = inside_zero(X2_src_begin,
		                               X2_src_end,
									   X2_trg_begin,
									   X2_trg_end);

	float prob = 1.0; 

	if (X1_src_begin > src_begin &&
		X1_src_end < src_end &&
		X1_trg_begin > trg_begin &&
		X1_trg_end < trg_end &&
		X2_src_begin > src_begin &&
		X2_src_end < src_end &&
		X2_trg_begin > trg_begin &&
		X2_trg_end < trg_end)
	{
		float p1 = (1.0 - getPointProb(src_begin, trg_end)) *
			       (1.0 - getPointProb(src_begin, trg_begin)) *
				   (1.0 - getPointProb(src_end, trg_begin)) *
				   (1.0 - getPointProb(src_end, trg_end)) *
				   getSrcRangeTwoGapsProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end) *
				   getSrcRangeTwoGapsProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end) *
				   getTrgRangeTwoGapsProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end) *
				   getTrgRangeTwoGapsProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p2 = getPointProb(src_begin, trg_end) *
			       (1.0 - getPointProb(src_begin, trg_begin)) *
				   (1.0 - getPointProb(src_end, trg_begin)) *
				   (1.0 - getPointProb(src_end, trg_end)) *
				   getSrcRangeTwoGapsProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end) *
				   getTrgRangeTwoGapsProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p3 = (1.0 - getPointProb(src_begin, trg_end)) *
			       getPointProb(src_begin, trg_begin) *
				   (1.0 - getPointProb(src_end, trg_begin)) *
				   (1.0 - getPointProb(src_end, trg_end)) *
				   getSrcRangeTwoGapsProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end) *
				   getTrgRangeTwoGapsProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p4 = (1.0 - getPointProb(src_begin, trg_end)) *
			       (1.0 - getPointProb(src_begin, trg_begin)) *
				   getPointProb(src_end, trg_begin) *
				   (1.0 - getPointProb(src_end, trg_end)) *
				   getSrcRangeTwoGapsProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end) *
				   getTrgRangeTwoGapsProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p5 = (1.0 - getPointProb(src_begin, trg_end)) *
			       (1.0 - getPointProb(src_begin, trg_begin)) *
				   (1.0 - getPointProb(src_end, trg_begin)) *
				   getPointProb(src_end, trg_end) *
				   getSrcRangeTwoGapsProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end) *
				   getTrgRangeTwoGapsProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p6 = getPointProb(src_begin, trg_end) *
			       (1.0 - getPointProb(src_begin, trg_begin)) *
				   getPointProb(src_end, trg_begin) *
				   (1.0 - getPointProb(src_end, trg_end));

		float p7 = (1.0 - getPointProb(src_begin, trg_end)) *
			       getPointProb(src_begin, trg_begin) *
				   (1.0 - getPointProb(src_end, trg_begin)) *
				   getPointProb(src_end, trg_end);

		float p8 = getPointProb(src_begin, trg_end) *
			       getPointProb(src_begin, trg_begin) *
				   (1.0 - getPointProb(src_end, trg_begin)) *
				   (1.0 - getPointProb(src_end, trg_end)) *
				   getTrgRangeTwoGapsProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p9 = (1.0 - getPointProb(src_begin, trg_end)) *
			       getPointProb(src_begin, trg_begin) *
				   getPointProb(src_end, trg_begin) *
				   (1.0 - getPointProb(src_end, trg_end)) *
				   getSrcRangeTwoGapsProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end);

		float p10 = (1.0 - getPointProb(src_begin, trg_end)) *
			        (1.0 - getPointProb(src_begin, trg_begin)) *
				    getPointProb(src_end, trg_begin) *
				    getPointProb(src_end, trg_end) *
					getTrgRangeTwoGapsProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p11 = getPointProb(src_begin, trg_end) *
			        (1.0 - getPointProb(src_begin, trg_begin)) *
				    (1.0 - getPointProb(src_end, trg_begin)) *
				    getPointProb(src_end, trg_end) *
					getSrcRangeTwoGapsProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end);

		float p12 = (1.0 - getPointProb(src_begin, trg_end)) *
			        getPointProb(src_begin, trg_begin) *
				    getPointProb(src_end, trg_begin) *
				    getPointProb(src_end, trg_end);

		float p13 = getPointProb(src_begin, trg_end) *
			        (1.0 - getPointProb(src_begin, trg_begin)) *
				    getPointProb(src_end, trg_begin) *
				    getPointProb(src_end, trg_end);

		float p14 = getPointProb(src_begin, trg_end) *
			        getPointProb(src_begin, trg_begin) *
				    (1.0 - getPointProb(src_end, trg_begin)) *
				    getPointProb(src_end, trg_end);

		float p15 = getPointProb(src_begin, trg_end) *
			        getPointProb(src_begin, trg_begin) *
				    getPointProb(src_end, trg_begin) *
				    (1.0 - getPointProb(src_end, trg_end));

		float p16 = getPointProb(src_begin, trg_end) *
			        getPointProb(src_begin, trg_begin) *
				    getPointProb(src_end, trg_begin) *
				    getPointProb(src_end, trg_end);

		prob = p1 + p2 + p3 + p4 + p5 + p6 + p7 + p8 +
			   p9 + p10 + p11 + p12 + p13 + p14 + p15 + p16;
	}
	else if (X1_src_begin > src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin > trg_begin &&
		     X1_trg_end < trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end < src_end &&
		     X2_trg_begin == trg_begin &&
		     X2_trg_end < trg_end)
	{
		float p1 = (1.0 - getPointProb(src_begin, trg_end)) *
			       (1.0 - getPointProb(src_end, trg_end)) *
				   getSrcRangeTwoGapsProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end) *
				   getTrgRangeTwoGapsProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end) *
				   getTrgRangeTwoGapsProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p2 = getPointProb(src_begin, trg_end) *
			       (1.0 - getPointProb(src_end, trg_end)) *
				   getTrgRangeTwoGapsProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p3 = (1.0 - getPointProb(src_begin, trg_end)) *
			       getPointProb(src_end, trg_end) * 
				   getTrgRangeTwoGapsProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p4 = getPointProb(src_begin, trg_end) *
			       getPointProb(src_end, trg_end);

		prob = p1 + p2 + p3 + p4;
	}
	else if (X1_src_begin > src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin > trg_begin &&
		     X1_trg_end < trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end == src_end &&
		     X2_trg_begin > trg_begin &&
		     X2_trg_end < trg_end)
	{
		float p1 = (1.0 - getPointProb(src_begin, trg_begin)) *
			       (1.0 - getPointProb(src_begin, trg_end)) *
				   getSrcRangeTwoGapsProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end) *
				   getSrcRangeTwoGapsProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end) *
				   getTrgRangeTwoGapsProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p2 = getPointProb(src_begin, trg_begin) *
			       (1.0 - getPointProb(src_begin, trg_end)) *
				   getSrcRangeTwoGapsProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end);

		float p3 = (1.0 - getPointProb(src_begin, trg_begin)) *
			       getPointProb(src_begin, trg_end) *
				   getSrcRangeTwoGapsProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end);

		float p4 = getPointProb(src_begin, trg_begin) *
			       getPointProb(src_begin, trg_end);

		prob = p1 + p2 + p3 + p4;
	}
	else if (X1_src_begin > src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin > trg_begin &&
		     X1_trg_end < trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end < src_end &&
		     X2_trg_begin > trg_begin &&
		     X2_trg_end == trg_end)
	{
		float p1 = (1.0 - getPointProb(src_begin, trg_begin)) *
			       (1.0 - getPointProb(src_end, trg_begin)) *
				   getSrcRangeTwoGapsProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end) *
				   getTrgRangeTwoGapsProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end) *
				   getTrgRangeTwoGapsProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p2 = getPointProb(src_begin, trg_begin) *
			       (1.0 - getPointProb(src_end, trg_begin)) *
				   getTrgRangeTwoGapsProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p3 = (1.0 - getPointProb(src_begin, trg_begin)) *
			       getPointProb(src_end, trg_begin) *
                   getTrgRangeTwoGapsProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p4 = getPointProb(src_begin, trg_begin) *
			       getPointProb(src_end, trg_begin);

		prob = p1 + p2 + p3 + p4;
	}
	else if (X1_src_begin > src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin > trg_begin &&
		     X1_trg_end < trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end == src_end &&
		     X2_trg_begin == trg_begin &&
		     X2_trg_end < trg_end)
	{
		float p1 = (1.0 - getPointProb(src_begin, trg_end)) *
			       getSrcRangeTwoGapsProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end) *
				   getTrgRangeTwoGapsProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p2 = getPointProb(src_begin, trg_end);

		prob = p1 + p2;
	}
	else if (X1_src_begin > src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin > trg_begin &&
		     X1_trg_end < trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end == src_end &&
		     X2_trg_begin > trg_begin &&
		     X2_trg_end == trg_end)
	{
		float p1 = (1.0 - getPointProb(src_begin, trg_begin)) *
			       getSrcRangeTwoGapsProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end) *
				   getTrgRangeTwoGapsProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p2 = getPointProb(src_begin, trg_begin);

		prob = p1 + p2;
	}
	else if (X1_src_begin == src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin > trg_begin &&
		     X1_trg_end < trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end < src_end &&
		     X2_trg_begin > trg_begin &&
		     X2_trg_end < trg_end)
	{
		float p1 = (1.0 - getPointProb(src_end, trg_begin)) *
			       (1.0 - getPointProb(src_end, trg_end)) *
				   getSrcRangeTwoGapsProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end) *
				   getSrcRangeTwoGapsProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end);

		float p2 = getPointProb(src_end, trg_begin) *
			       (1.0 - getPointProb(src_end, trg_end)) *
				   getSrcRangeTwoGapsProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end);

		float p3 = (1.0 - getPointProb(src_end, trg_begin)) *
			       getPointProb(src_end, trg_end) *
				   getSrcRangeTwoGapsProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end);

		float p4 = getPointProb(src_end, trg_begin) *
			       getPointProb(src_end, trg_end);

		prob = p1 + p2 + p3 + p4;
	}
	else if (X1_src_begin == src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin > trg_begin &&
		     X1_trg_end < trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end < src_end &&
		     X2_trg_begin == trg_begin &&
		     X2_trg_end < trg_end)
	{
		float p1 = (1.0 - getPointProb(src_end, trg_end)) * 
			       getSrcRangeTwoGapsProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end) *
				   getTrgRangeTwoGapsProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p2 = getPointProb(src_end, trg_end);

		prob = p1 + p2;
	}
	else if (X1_src_begin == src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin > trg_begin &&
		     X1_trg_end < trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end == src_end &&
		     X2_trg_begin > trg_begin &&
		     X2_trg_end < trg_end)
	{
		float p1 = getSrcRangeTwoGapsProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end) *
			       getSrcRangeTwoGapsProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end);

		prob = p1;
	}
	else if (X1_src_begin == src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin > trg_begin &&
		     X1_trg_end < trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end < src_end &&
		     X2_trg_begin > trg_begin &&
		     X2_trg_end == trg_end)
	{
		float p1 = (1.0 - getPointProb(src_end, trg_begin)) *
			       getSrcRangeTwoGapsProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end) *
				   getTrgRangeTwoGapsProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);
		
		float p2 = getPointProb(src_end, trg_begin);

		prob = p1 + p2;
	}
	else if (X1_src_begin == src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin > trg_begin &&
		     X1_trg_end < trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end == src_end &&
		     X2_trg_begin == trg_begin &&
		     X2_trg_end < trg_end)
	{
		float p1 = getSrcRangeTwoGapsProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end);

		prob = p1;
	}
	else if (X1_src_begin == src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin > trg_begin &&
		     X1_trg_end < trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end == src_end &&
		     X2_trg_begin > trg_begin &&
		     X2_trg_end == trg_end)
	{
		float p1 = getSrcRangeTwoGapsProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end);

		prob = p1;
	}
	else if (X1_src_begin > src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin > trg_begin &&
		     X1_trg_end == trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end < src_end &&
		     X2_trg_begin > trg_begin &&
		     X2_trg_end < trg_end)
	{
		float p1 = (1.0 - getPointProb(src_begin, trg_begin)) *
			       (1.0 - getPointProb(src_end, trg_begin)) *
				   getSrcRangeTwoGapsProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end) *
				   getTrgRangeTwoGapsProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end) *
				   getTrgRangeTwoGapsProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p2 = getPointProb(src_begin, trg_begin) *
			       (1.0 - getPointProb(src_end, trg_begin)) *
				   getTrgRangeTwoGapsProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p3 = (1.0 - getPointProb(src_begin, trg_begin)) *
			       getPointProb(src_end, trg_begin) *
				   getTrgRangeTwoGapsProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p4 = getPointProb(src_begin, trg_begin) *
			       getPointProb(src_end, trg_begin);

		prob = p1 + p2 + p3 + p4;
	}
	else if (X1_src_begin > src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin > trg_begin &&
		     X1_trg_end == trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end < src_end &&
		     X2_trg_begin == trg_begin &&
		     X2_trg_end < trg_end)
	{
		float p1 = getTrgRangeTwoGapsProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end) *
				   getTrgRangeTwoGapsProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		prob = p1;
	}
	else if (X1_src_begin > src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin > trg_begin &&
		     X1_trg_end == trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end == src_end &&
		     X2_trg_begin > trg_begin &&
		     X2_trg_end < trg_end)
	{
		float p1 = (1.0 - getPointProb(src_begin, trg_begin)) *
			       getSrcRangeTwoGapsProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end) *
				   getTrgRangeTwoGapsProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p2 = getPointProb(src_begin, trg_begin);

		prob = p1 + p2;
	}
	else if (X1_src_begin > src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin > trg_begin &&
		     X1_trg_end == trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end == src_end &&
		     X2_trg_begin == trg_begin &&
		     X2_trg_end < trg_end)
	{
		float p1 = getTrgRangeTwoGapsProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		prob = p1;
	}
	else if (X1_src_begin > src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin == trg_begin &&
		     X1_trg_end < trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end < src_end &&
		     X2_trg_begin > trg_begin &&
		     X2_trg_end < trg_end)
	{
		float p1 = (1.0 - getPointProb(src_begin, trg_end)) *
			       (1.0 - getPointProb(src_end, trg_end)) *
				   getSrcRangeTwoGapsProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end) *
				   getTrgRangeTwoGapsProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end) *
				   getTrgRangeTwoGapsProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);
				   
		float p2 = getPointProb(src_begin, trg_end) *
			       (1.0 - getPointProb(src_end, trg_end)) *
				   getTrgRangeTwoGapsProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p3 = (1.0 - getPointProb(src_begin, trg_end)) *
			       getPointProb(src_end, trg_end) *
				   getTrgRangeTwoGapsProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p4 = getPointProb(src_begin, trg_end) *
			       getPointProb(src_end, trg_end);

		prob = p1 + p2 + p3 + p4;
	}
	else if (X1_src_begin > src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin == trg_begin &&
		     X1_trg_end < trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end == src_end &&
		     X2_trg_begin > trg_begin &&
		     X2_trg_end < trg_end)
	{
		float p1 = (1.0 - getPointProb(src_begin, trg_end)) *
			       getSrcRangeTwoGapsProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end) *
				   getTrgRangeTwoGapsProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p2 = getPointProb(src_begin, trg_end);

		prob = p1 + p2;
	}
	else if (X1_src_begin > src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin == trg_begin &&
		     X1_trg_end < trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end < src_end &&
		     X2_trg_begin > trg_begin &&
		     X2_trg_end == trg_end)
	{
		float p1 = getTrgRangeTwoGapsProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end) *
				   getTrgRangeTwoGapsProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);
		
		prob = p1; 
	}
	else if (X1_src_begin > src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin == trg_begin &&
		     X1_trg_end < trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end == src_end &&
		     X2_trg_begin > trg_begin &&
		     X2_trg_end == trg_end)
	{
		float p1 = getTrgRangeTwoGapsProb(src_begin, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		prob = p1;
	}
	else if (X1_src_begin == src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin == trg_begin &&
		     X1_trg_end < trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end < src_end &&
		     X2_trg_begin > trg_begin &&
		     X2_trg_end < trg_end)
	{
		float p1 = (1.0 - getPointProb(src_end, trg_end)) *
			       getSrcRangeTwoGapsProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end) *
				   getTrgRangeTwoGapsProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p2 = getPointProb(src_end, trg_end);

		prob = p1 + p2;
	}
	else if (X1_src_begin == src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin == trg_begin &&
		     X1_trg_end < trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end < src_end &&
		     X2_trg_begin > trg_begin &&
		     X2_trg_end == trg_end)
	{
		float p1 = getTrgRangeTwoGapsProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		prob = p1;
	}
	else if (X1_src_begin == src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin == trg_begin &&
		     X1_trg_end < trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end == src_end &&
		     X2_trg_begin > trg_begin &&
		     X2_trg_end < trg_end)
	{
		float p1 = getSrcRangeTwoGapsProb(trg_end, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end);

		prob = p1;
	}
	else if (X1_src_begin == src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin == trg_begin &&
		     X1_trg_end < trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end == src_end &&
		     X2_trg_begin > trg_begin &&
		     X2_trg_end == trg_end)
	{
		prob = 1.0;

		map<pair<int, int>, float>::iterator iter;

		for (iter = matrix.begin(); iter != matrix.end(); iter++)
		{
			int sp = iter->first.first,
				tp = iter->first.second;
			float p = iter->second;

			if (sp > X1_src_end &&
				sp < X2_src_begin &&
				tp > X1_trg_end &&
				tp < X2_trg_begin)
			{
				prob *= 1.0 - p;
			}
		}

		prob = 1.0 - prob;
	}
	else if (X1_src_begin == src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin > trg_begin &&
		     X1_trg_end == trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end < src_end &&
		     X2_trg_begin > trg_begin &&
		     X2_trg_end < trg_end)
	{
		float p1 = (1.0 - getPointProb(src_end, trg_begin)) *
			       getSrcRangeTwoGapsProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end) *
				   getTrgRangeTwoGapsProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		float p2 = getPointProb(src_end, trg_begin);

		prob = p1 + p2;
	}
	else if (X1_src_begin == src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin > trg_begin &&
		     X1_trg_end == trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end < src_end &&
		     X2_trg_begin == trg_begin &&
		     X2_trg_end < trg_end)
	{
		float p1 = getTrgRangeTwoGapsProb(src_end, trg_begin, trg_end, X1_trg_begin, X1_trg_end, X2_trg_begin, X2_trg_end);

		prob = p1;
	}
	else if (X1_src_begin == src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin > trg_begin &&
		     X1_trg_end == trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end == src_end &&
		     X2_trg_begin > trg_begin &&
		     X2_trg_end < trg_end)
	{
		float p1 = getSrcRangeTwoGapsProb(trg_begin, src_begin, src_end, X1_src_begin, X1_src_end, X2_src_begin, X2_src_end);

		prob = p1;
	}
	else if (X1_src_begin == src_begin &&
		     X1_src_end < src_end &&
		     X1_trg_begin > trg_begin &&
		     X1_trg_end == trg_end &&
		     X2_src_begin > src_begin &&
		     X2_src_end == src_end &&
		     X2_trg_begin == trg_begin &&
		     X2_trg_end < trg_end)
	{
		prob = 1.0;

		map<pair<int, int>, float>::iterator iter;

		for (iter = matrix.begin(); iter != matrix.end(); iter++)
		{
			int sp = iter->first.first,
				tp = iter->first.second;
			float p = iter->second;

			if (sp > X1_src_end &&
				sp < X2_src_begin &&
				tp > X2_trg_end &&
				tp < X1_trg_begin)
			{
				prob *= 1.0 - p;
			}
		}

		prob = 1.0 - prob;
	}
	else
	{
		cerr << "\nERROR at [Matrix::inside_two]: "
			 << "it is impossible to get here!\n"
			 << "["
			 << src_begin
			 << ", "
			 << src_end
			 << ", "
			 << trg_begin
			 << ", "
			 << trg_end
			 << "] -> "
			 << "["
			 << X1_src_begin
			 << ", "
			 << X1_src_end
			 << ", "
			 << X1_trg_begin
			 << ", "
			 << X1_trg_end
			 << "] ["
			 << X2_src_begin
			 << ", "
			 << X2_src_end
			 << ", "
			 << X2_trg_begin
			 << ", "
			 << X2_trg_end
			 << "]"
			 << endl;

		exit(1);
	}

	return X1_inside_prob * X2_inside_prob * prob;
}

/************************************************
  outside prob for zero variable
************************************************/
float Matrix::outside_zero(int src_begin,
		                   int src_end,
				    	   int trg_begin,
					       int trg_end) const
{
	float prob = 1.0;

	map<pair<int, int>, float>::const_iterator iter;

	for (iter = matrix.begin(); iter != matrix.end(); iter++)
	{
		int sp = iter->first.first,
			tp = iter->first.second;
		float p = iter->second;

		if (sp >= src_begin &&
			sp <= src_end &&
			(tp < trg_begin ||
			 tp > trg_end) ||
			(sp < src_begin ||
			 sp > src_end) &&
			tp >= trg_begin &&
			tp <= trg_end)
		{
			prob *= 1.0 - p;
		}
	}

	return prob;
}

/************************************************
  outisde prob for one variable
************************************************/
float Matrix::outside_one(int src_begin,
		                  int src_end,
				    	  int trg_begin,
					      int trg_end,
					      int X1_src_begin,
					      int X1_src_end,
					      int X1_trg_begin,
					      int X1_trg_end) const
{
	float prob = 1.0;

	map<pair<int, int>, float>::const_iterator iter;

	for (iter = matrix.begin(); iter != matrix.end(); iter++)
	{
		int sp = iter->first.first,
			tp = iter->first.second;
		float p = iter->second;

		if (sp >= src_begin &&
			sp <= src_end &&
			(tp < trg_begin ||
			 tp > trg_end) ||
			(sp < src_begin ||
			 sp > src_end) &&
			tp >= trg_begin &&
			tp <= trg_end ||
			sp >= X1_src_begin &&
			sp <= X1_src_end &&
			(tp < X1_trg_begin ||
			 tp > X1_trg_end) ||
			(sp < X1_src_begin ||
			 sp > X1_src_end) &&
			tp >= X1_trg_begin &&
			tp <= X1_trg_end)
		{
			prob *= 1.0 - p;
		}
	}

	return prob;
}

/************************************************
  outside prob for two variables
************************************************/
float Matrix::outside_two(int src_begin,
		                  int src_end,
				    	  int trg_begin,
					      int trg_end,
					      int X1_src_begin,
			    		  int X1_src_end,
				    	  int X1_trg_begin,
			    		  int X1_trg_end,
				    	  int X2_src_begin,
			    		  int X2_src_end,
				    	  int X2_trg_begin,
	    				  int X2_trg_end) const
{
	float prob = 1.0;

	map<pair<int, int>, float>::const_iterator iter;

	for (iter = matrix.begin(); iter != matrix.end(); iter++)
	{
		int sp = iter->first.first,
			tp = iter->first.second;
		float p = iter->second;

		if (sp >= src_begin &&
			sp <= src_end &&
			(tp < trg_begin ||
			 tp > trg_end) ||
			(sp < src_begin ||
			 sp > src_end) &&
			tp >= trg_begin &&
			tp <= trg_end ||
			sp >= X1_src_begin &&
			sp <= X1_src_end &&
			(tp < X1_trg_begin ||
			 tp > X1_trg_end) ||
			(sp < X1_src_begin ||
			 sp > X1_src_end) &&
			tp >= X1_trg_begin &&
			tp <= X1_trg_end ||
			sp >= X2_src_begin &&
			sp <= X2_src_end &&
			(tp < X2_trg_begin ||
			 tp > X2_trg_end) ||
			(sp < X2_src_begin ||
			 sp > X2_src_end) &&
			tp >= X2_trg_begin &&
			tp <= X2_trg_end)
		{
			prob *= 1.0 - p;
		}
	}

	return prob;
}

/************************************************
  get point probabiity
************************************************/
float Matrix::getPointProb(int sp,
		                   int tp) const
{
	pair<int, int> pr(sp, tp);

	map<pair<int, int>, float>::const_iterator iter = matrix.find(pr);

	if (iter == matrix.end())
	{
		return 0;
	}
	else
	{
		return iter->second;
	}
}

/************************************************
  get prob for the source range without gaps
************************************************/
float Matrix::getSrcRangeZeroGapProb(int tp,
		                             int src_begin,
				    				 int src_end) const
{
	float prob = 1.0;

	map<pair<int, int>, float>::const_iterator iter;

	for (iter = matrix.begin(); iter != matrix.end(); iter++)
	{
		if (iter->first.second == tp &&
			iter->first.first > src_begin &&
			iter->first.first < src_end)
		{
			prob *= 1.0 - iter->second;
		}
	}

	return 1.0 - prob;
}

/************************************************
  get prob for the source range with one gap
************************************************/
float Matrix::getSrcRangeOneGapProb(int tp,
		                            int src_begin,
				    				int src_end,
					    			int X1_src_begin,
						    		int X1_src_end) const
{
	float prob = 1.0;

	map<pair<int, int>, float>::const_iterator iter;

	for (iter = matrix.begin(); iter != matrix.end(); iter++)
	{
		if (iter->first.second == tp &&
			iter->first.first > src_begin &&
			iter->first.first < src_end &&
			(iter->first.first < X1_src_begin ||
			 iter->first.first > X1_src_end))
		{
			prob *= 1.0 - iter->second;
		}
	}

	return 1.0 - prob;
}

/************************************************
  get prob for the source range with two gaps
************************************************/
float Matrix::getSrcRangeTwoGapsProb(int tp,
		                             int src_begin,
				    			 	 int src_end,
					    			 int X1_src_begin,
						    		 int X1_src_end,
							    	 int X2_src_begin,
							    	 int X2_src_end) const
{
	float prob = 1.0;

	map<pair<int, int>, float>::const_iterator iter;

	for (iter = matrix.begin(); iter != matrix.end(); iter++)
	{
		if (iter->first.second == tp &&
			iter->first.first > src_begin &&
			iter->first.first < src_end &&
			(iter->first.first < X1_src_begin ||
			 iter->first.first > X1_src_end) &&
			(iter->first.first < X2_src_begin ||
			 iter->first.first > X2_src_end))
		{
			prob *= 1.0 - iter->second;
		}
	}

	return 1.0 - prob;
}

/************************************************
  get prob for the target range without gaps
************************************************/
float Matrix::getTrgRangeZeroGapProb(int sp,
		                             int trg_begin,
				    				 int trg_end) const
{
	float prob = 1.0;

	map<pair<int, int>, float>::const_iterator iter;

	for (iter = matrix.begin(); iter != matrix.end(); iter++)
	{
		if (iter->first.first == sp &&
			iter->first.second > trg_begin &&
			iter->first.second < trg_end)
		{
			prob *= 1.0 - iter->second;
		}
	}

	return 1.0 - prob;
}

/************************************************
  get prob for the target range with one gap
************************************************/
float Matrix::getTrgRangeOneGapProb(int sp,
		                            int trg_begin,
				    				int trg_end,
					    			int X1_trg_begin,
						    		int X1_trg_end) const
{
	float prob = 1.0;

	map<pair<int, int>, float>::const_iterator iter;

	for (iter = matrix.begin(); iter != matrix.end(); iter++)
	{
		if (iter->first.first == sp &&
			iter->first.second > trg_begin &&
			iter->first.second < trg_end &&
			(iter->first.second < X1_trg_begin ||
			 iter->first.second > X1_trg_end))
		{
			prob *= 1.0 - iter->second;
		}
	}

	return 1.0 - prob;
}

/************************************************
  get prob for the target range with two gaps
************************************************/
float Matrix::getTrgRangeTwoGapsProb(int sp,
		                             int trg_begin,
				    			 	 int trg_end,
					    			 int X1_trg_begin,
						    		 int X1_trg_end,
							    	 int X2_trg_begin,
								     int X2_trg_end) const
{
	float prob = 1.0;

	map<pair<int, int>, float>::const_iterator iter;

	for (iter = matrix.begin(); iter != matrix.end(); iter++)
	{
		if (iter->first.first == sp &&
			iter->first.second > trg_begin &&
			iter->first.second < trg_end &&
			(iter->first.second < X1_trg_begin ||
			 iter->first.second > X1_trg_end) &&
			(iter->first.second < X2_trg_begin ||
			 iter->first.second > X2_trg_end))
		{
			prob *= 1.0 - iter->second;
		}
	}

	return 1.0 - prob;
}

/************************************************
  check validity
************************************************/
bool Matrix::isValid(int srcSentLen,
		             int trgSentLen) const
{
	map<pair<int, int>, float>::const_iterator iter;

	for (iter = matrix.begin(); iter != matrix.end(); iter++)
	{
		if (iter->first.first < 1 ||
			iter->first.first > srcSentLen ||
			iter->first.second < 1 ||
			iter->first.second > trgSentLen)
		{
			return false;
		}
	}

	return true;
}

/************************************************
  get target span
************************************************/
void Matrix::getTrgSpan(int src_begin,
		                int src_end,
				    	int& trg_begin,
					    int& trg_end) const
{
	trg_begin = 0;
	trg_end = 0;

	map<pair<int, int>, float>::const_iterator iter;

	for (iter = matrix.begin(); iter != matrix.end(); iter++)
	{
		if (iter->first.first >= src_begin &&
			iter->first.first <= src_end)
		{
			if (trg_begin == 0 ||
				iter->first.second < trg_begin)
			{
				trg_begin = iter->first.second;
			}

			if (trg_end == 0 ||
				iter->first.second > trg_end)
			{
				trg_end = iter->first.second;
			}
		}
	}
}

/************************************************
  get sub alignment
************************************************/
void Matrix::getSubAlignment(int src_begin,
		                     int src_end,
				    		 int trg_begin,
					    	 int trg_end,
						     map<pair<int, int>, float>& a1,
						     map<pair<int, int>, float>& a2) const
{
	a1.clear();
	a2.clear();

	map<pair<int, int>, float>::const_iterator iter;

	for (iter = matrix.begin(); iter != matrix.end(); iter++)
	{
		int sp = iter->first.first,
			tp = iter->first.second;
		float p = iter->second;

		if (sp >= src_begin &&
			sp <= src_end &&
			tp >= trg_begin &&
			tp <= trg_end)
		{
			int new_sp = sp - src_begin + 1,
				new_tp = tp - trg_begin + 1;
			a1.insert(map<pair<int, int>, float>::value_type(pair<int, int>(new_sp, new_tp), p));
			a2.insert(map<pair<int, int>, float>::value_type(pair<int, int>(new_tp, new_sp), p));
		}
	}
}

void Matrix::getSubAlignment(int src_begin,
		                     int src_end,
				    		 int trg_begin,
					    	 int trg_end,
					    	 int X1_src_begin,
						     int X1_src_end,
						     int X1_trg_begin,
						     int X1_trg_end,
						     map<pair<int, int>, float>& a1,
						     map<pair<int, int>, float>& a2) const
{
	a1.clear();
	a2.clear();

	map<pair<int, int>, float>::const_iterator iter;
	float flag = false;

	for (iter = matrix.begin(); iter != matrix.end(); iter++)
	{
		int sp = iter->first.first,
			tp = iter->first.second;
		float p = iter->second;

		if (sp >= src_begin &&
			sp <= src_end &&
			tp >= trg_begin &&
			tp <= trg_end)
		{
			if (sp >= X1_src_begin &&
				sp <= X1_src_end &&
				tp >= X1_trg_begin &&
				tp <= X1_trg_end)
			{
				if (!flag)
				{
					int new_sp = X1_src_begin - src_begin + 1,
						new_tp = X1_trg_begin - trg_begin + 1;
					a1.insert(map<pair<int, int>, float>::value_type(pair<int, int>(new_sp, new_tp), p));
					a2.insert(map<pair<int, int>, float>::value_type(pair<int, int>(new_tp, new_sp), p));
					flag = true;
				}
			}
			else if ((sp < X1_src_begin ||
				      sp > X1_src_end) &&
					 (tp < X1_trg_begin ||
					  tp > X1_trg_end))
			{
				int new_sp = sp,
					new_tp = tp;

				if (sp > X1_src_end)
				{
					new_sp -= X1_src_end - X1_src_begin;
				}

				if (tp > X1_trg_end)
				{
					new_tp -= X1_trg_end - X1_trg_begin;
				}

				new_sp -= src_begin - 1;
				new_tp -= trg_begin - 1;

				a1.insert(map<pair<int, int>, float>::value_type(pair<int, int>(new_sp, new_tp), p));
				a2.insert(map<pair<int, int>, float>::value_type(pair<int, int>(new_tp, new_sp), p));
			}
		}
	}
}

void Matrix::getSubAlignment(int src_begin,
		                     int src_end,
				    		 int trg_begin,
					    	 int trg_end,
						     int X1_src_begin,
    						 int X1_src_end,
	    					 int X1_trg_begin,
		    				 int X1_trg_end,
			    			 int X2_src_begin,
				    		 int X2_src_end,
					    	 int X2_trg_begin,
		    				 int X2_trg_end,
			    			 map<pair<int, int>, float>& a1,
				    		 map<pair<int, int>, float>& a2) const
{
	a1.clear();
	a2.clear();

	map<pair<int, int>, float>::const_iterator iter;
	float flag1 = false,
		  flag2 = false;

	for (iter = matrix.begin(); iter != matrix.end(); iter++)
	{
		int sp = iter->first.first,
			tp = iter->first.second;
		float p = iter->second;

		if (sp >= src_begin &&
			sp <= src_end &&
			tp >= trg_begin &&
			tp <= trg_end)
		{
			if (sp >= X1_src_begin &&
				sp <= X1_src_end &&
				tp >= X1_trg_begin &&
				tp <= X1_trg_end)
			{
				if (!flag1)
				{
					int new_sp = X1_src_begin,
						new_tp = X1_trg_begin;

					if (X1_src_begin > X2_src_end)
					{
						new_sp -= X2_src_end - X2_src_begin;
					}

					if (X1_trg_begin > X2_trg_end)
					{
						new_tp -= X2_trg_end - X2_trg_begin;
					}

					new_sp -= src_begin - 1;
					new_tp -= trg_begin - 1;

					a1.insert(map<pair<int, int>, float>::value_type(pair<int, int>(new_sp, new_tp), p));
					a2.insert(map<pair<int, int>, float>::value_type(pair<int, int>(new_tp, new_sp), p));

					flag1 = true;
				}
			}
			else if (sp >= X2_src_begin &&
				     sp <= X2_src_end &&
				     tp >= X2_trg_begin &&
				     tp <= X2_trg_end)
			{
				if (!flag2)
				{
					int new_sp = X2_src_begin,
						new_tp = X2_trg_begin;

					if (X2_src_begin > X1_src_end)
					{
						new_sp -= X1_src_end - X1_src_begin;
					}

					if (X2_trg_begin > X1_trg_end)
					{
						new_tp -= X1_trg_end - X1_trg_begin;
					}

					new_sp -= src_begin - 1;
					new_tp -= trg_begin - 1;

					a1.insert(map<pair<int, int>, float>::value_type(pair<int, int>(new_sp, new_tp), p));
					a2.insert(map<pair<int, int>, float>::value_type(pair<int, int>(new_tp, new_sp), p));

					flag2 = true;
				}
			}
			else if ((sp < X1_src_begin ||
				      sp > X1_src_end) &&
					 (sp < X2_src_begin ||
					  sp > X2_src_end) &&
					 (tp < X1_trg_begin ||
					  tp > X1_trg_end) &&
					 (tp < X2_trg_begin ||
					  tp > X2_trg_end))
			{
				int new_sp = sp,
					new_tp = tp;

				if (sp > X1_src_end)
				{
					new_sp -= X1_src_end - X1_src_begin;
				}

				if (sp > X2_src_end)
				{
					new_sp -= X2_src_end - X2_src_begin;
				}

				if (tp > X1_trg_end)
				{
					new_tp -= X1_trg_end - X1_trg_begin;
				}

				if (tp > X2_trg_end)
				{
					new_tp -= X2_trg_end - X2_trg_begin;
				}

				new_sp -= src_begin - 1;
				new_tp -= trg_begin - 1;

				a1.insert(map<pair<int, int>, float>::value_type(pair<int, int>(new_sp, new_tp), p));
				a2.insert(map<pair<int, int>, float>::value_type(pair<int, int>(new_tp, new_sp), p));
			}
		}
	}
}

/************************************************
  source side aligned?
************************************************/
bool Matrix::src_aligned(int src_pos) const
{
	map<pair<int, int>, float>::const_iterator iter;

	for (iter = matrix.begin(); iter != matrix.end(); iter++)
	{
		if (iter->first.first == src_pos)
		{
			return true;
		}
	}

	return false;
}

/************************************************
  target side aligned?
************************************************/
bool Matrix::trg_aligned(int trg_pos) const
{
	map<pair<int, int>, float>::const_iterator iter;

	for (iter = matrix.begin(); iter != matrix.end(); iter++)
	{
		if (iter->first.second == trg_pos)
		{
			return true;
		}
	}

	return false;
}
