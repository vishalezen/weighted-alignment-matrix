#ifndef EXTRACT_H
#define EXTRACT_H

#include "Rule.h"
#include "Matrix.h"
#include "TTable.h"

class Extract
{
public:
	/* member functions */
	// constructor
	Extract();
	// extract from file
	void extractFile(const char* srcFileName,
		             const char* trgFileName,
					 const char* agtFileName,
					 const char* s2tFileName,
					 const char* t2sFileName,
					 float max_capacity,
					 float pruning_threshold);

private:
	/* data members */
	TTable s2tTTable;  // p(t|s)
	TTable t2sTTable;  // p(s|t)

	/* member functions */
	// extract from sentence
	void extractSent(const vector<string>& srcWordVec,
		             const vector<string>& trgWordVec,
					 Matrix& matrix,
					 map<Rule, vector<float> >& ruleFreq,
					 float pruning_threshold);
	// build word vector
	void buildWordVec(const string& line,
		              vector<string>& wordVec);
	// zero variable
	void zeroVariable(const vector<string>& srcWordVec,
		              const vector<string>& trgWordVec,
					  Matrix& matrix,
					  map<vector<int>, map<Rule, vector<float> > >& ruleMap,
					  float threshold);
	// one variable
	void oneVariable(const vector<string>& srcWordVec,
		             const vector<string>& trgWordVec,
					 Matrix& matrix,
					 map<vector<int>, map<Rule, vector<float> > >& ruleMap,
					 float threshold);
	// two variables
	void twoVariables(const vector<string>& srcWordVec,
		              const vector<string>& trgWordVec,
					  Matrix& matrix,
					  map<vector<int>, map<Rule, vector<float> > >& ruleMap,
					  float threshold);
	// calculate lexical weights
	float lexicalWeight(const vector<string>& src_rhs,
		                const vector<string>& trg_rhs,
						const map<pair<int, int>, float>& alignment,
						const TTable& tTable);
	// update rule map
	void updateRuleMap(const vector<int>& spanPair,
		               const Rule& rule,
		               float lst,
					   float lts,
					   float freq,
					   map<vector<int>, map<Rule, vector<float> > >& ruleMap);
	// show rule map
	void showRuleMap(const map<vector<int>, map<Rule, vector<float> > >& ruleMap);
	// output rule freq
	void output(map<vector<int>, map<Rule, vector<float> > >& ruleMap,
		        map<Rule, vector<float> >& ruleFreq);
	// update
	void updateRuleFreq(const map<Rule, vector<float> >& m1,
		                map<Rule, vector<float> >& m2);
	void updateRuleFreq(const Rule& rule,
		                const vector<float>& v,
						map<Rule, vector<float> >& m);
	// dump
	void dump(map<Rule, vector<float> >& m,
		      const char* fileName);
};

#endif
