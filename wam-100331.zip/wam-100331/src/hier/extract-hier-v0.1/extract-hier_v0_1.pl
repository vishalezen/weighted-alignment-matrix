#!/usr/bin/perl -w

# extract-hier v0.1
# 2010/03/03 - 2010/03/03
# (c) 2008-2010 Yang Liu

use strict;
use Getopt::Long "GetOptions";

my $BUILD_TTABLE = "/home3/ly/ly/projects/WAM-Release/src/hier/matrixBuildTTable-v0.2/matrixBuildTTable_v0_2";
my $EXTRACTOR = "/home3/ly/ly/projects/WAM-Release/src/hier/matrixExtractor-v0.7/matrixExtractor_v0_7";
my $MERGER = "/home3/ly/ly/projects/WAM-Release/src/hier/merger-v0.2/merger_v0_2";
my $NORMALIZER = "/home3/ly/ly/projects/WAM-Release/src/hier/normalizer-v0.2/normalizer_v0_2";
my $REVERSER = "/home3/ly/ly/projects/WAM-Release/src/hier/reverser-v0.2/reverser_v0_2";
my $GEN_RULE_TABLE = "/home3/ly/ly/projects/WAM-Release/src/hier/genRuleTable-v0.2/genRuleTable_v0_2";
my $LS = "ls"; # Windows: "dir /B", Linux: "ls"
my $RM = "rm"; # Windows: "del", Linux: "rm"

my($_SRC_FILE, $_TRG_FILE, $_AGT_FILE, $_MAX_CAPACITY, $_PRUNING_THRESHOLD,  $_RULE_TABLE_FILE, $_HELP);

$_HELP = 1 unless &GetOptions('src-file=s' => \$_SRC_FILE,
                              'trg-file=s' => \$_TRG_FILE,
                              'agt-file=s' => \$_AGT_FILE,
                              'max-capacity=f' => \$_MAX_CAPACITY,
							  'pruning-threshold=f' => \$_PRUNING_THRESHOLD,
                              'rule-table-file=s' => \$_RULE_TABLE_FILE,
                              'help' => \$_HELP);
                              
# check required arguments
&help unless $_SRC_FILE && $_TRG_FILE && $_AGT_FILE && $_RULE_TABLE_FILE;
my $___SRC_FILE = $_SRC_FILE;
my $___TRG_FILE = $_TRG_FILE;
my $___AGT_FILE = $_AGT_FILE;
my $___RULE_TABLE_FILE = $_RULE_TABLE_FILE;

# set optional arguments
my $___MAX_CAPACITY = 1000000;
my $___PRUNING_THRESHOLD = 0.1;

$___MAX_CAPACITY = $_MAX_CAPACITY if $_MAX_CAPACITY;
$___PRUNING_THRESHOLD = $_PRUNING_THRESHOLD if $_PRUNING_THRESHOLD;

# training
print "\nStep 1: build translation probability tables\n";
system("$BUILD_TTABLE $___SRC_FILE $___TRG_FILE $___AGT_FILE s2tTTable.txt t2sTTable.txt");

print "\nStep 2: extract rules\n";
system("$EXTRACTOR -s $___SRC_FILE -t $___TRG_FILE -a $___AGT_FILE -s2t s2tTTable.txt -t2s t2sTTable.txt -c $___MAX_CAPACITY -p $___PRUNING_THRESHOLD");
`$RM s2tTTable.txt t2sTTable.txt`;

print "\nStep 3: merge rule frequency files\n";
`$LS ruleFreq_*.txt > fileList.txt`;
system("$MERGER fileList.txt ruleFreq.txt");
`$RM ruleFreq_*.txt fileList.txt`;

print "\nStep 4: normalize to get direct rule table\n";
system("$NORMALIZER ruleFreq.txt ruleTable1.txt");

print "\nStep 5: reverse rule frequencies\n";
system("$REVERSER ruleFreq.txt $___MAX_CAPACITY");
`$RM ruleFreq.txt`;

print "\nStep 6: merge to get inverse rule frequencies\n";
`$LS r_ruleFreq_*.txt > fileList.txt`;
system("$MERGER fileList.txt r_ruleFreq.txt");
`$RM r_ruleFreq_*.txt fileList.txt`;

print "\nStep 7: normalize to get inverse relative frequencies\n";
system("$NORMALIZER r_ruleFreq.txt r_ruleTable.txt");
`$RM r_ruleFreq.txt`;

print "\nStep 8: reverse again\n";
system("$REVERSER r_ruleTable.txt $___MAX_CAPACITY");
`$RM r_ruleTable.txt`;

print "\nStep 9: merger to get inverse rule table\n";
`$LS r_ruleFreq_*.txt > fileList.txt`;
system("$MERGER fileList.txt ruleTable2.txt");
`$RM r_ruleFreq_*.txt fileList.txt`;

print "\nStep 10: generate the final rule table\n";
system("$GEN_RULE_TABLE ruleTable1.txt ruleTable2.txt $___RULE_TABLE_FILE");
`$RM ruleTable1.txt ruleTable2.txt`;

# help
sub help
{
	my $usage="Usage: matrixTraining [--help] ...\n".
	          "Required arguments:\n".
	          "  --src-file <src_file>                 source file\n".
	          "  --trg-file <trg_file>                 target file\n".
	          "  --agt-file <agt_file>                 alignment file\n".
	          "  --rule-table-file <rt_file>           rule table file\n".
	          "Optional arguments:\n".
	          "  --max-capacity <default: 1,000,000>   maximal capacity\n".
			  "  --pruning-threshold <default: 0.1>    pruning threshold\n".
	          "  --help                                prints this message to STDOUT\n";
	          
	print "$usage";
	exit;
}
