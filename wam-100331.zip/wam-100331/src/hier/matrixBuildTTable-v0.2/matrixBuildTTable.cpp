#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <vector>

using namespace std;

/************************************************
  version
************************************************/
void version()
{
	cout << "----------------------------------------\n"
		    " matrixBuildTTable v0.2\n"
			" 2010/03/03 - 2010/03/03\n"
			" (c) 2008-2010 Yang Liu\n"
			"----------------------------------------\n";
}

/************************************************
  build word vector
************************************************/
void buildWordVec(const string& line,
				  vector<string>& wordVec)
{
	wordVec.clear();
	wordVec.push_back("$NULL");

	istringstream iss(line.c_str());
	string w;

	while (iss >> w)
	{
		wordVec.push_back(w);
	}
}

/************************************************
  build word alignment
************************************************/
void buildAlignment(const string& line,
					map<pair<int, int>, float>& alignment)
{
	istringstream iss(line.c_str());
	string w;

	while (iss >> w)
	{
		int spp1 = w.find(':'),
			spp2 = w.find('/'),
			sp = atoi(w.substr(0, spp1).c_str()),
			tp = atoi(w.substr(spp1 + 1, spp2 - spp1 - 1).c_str());
		float prob = atof(w.substr(spp2 + 1, (int)w.size() - spp2 - 1).c_str());
		alignment.insert(map<pair<int, int>, float>::value_type(pair<int, int>(sp, tp), prob));
	}
}

/************************************************
  update rule frequency
************************************************/
void updateFreq(const string& word1,
				const string& word2,
				float freq,
				map<string, map<string, float> >& m)
{
	map<string, map<string, float> >::iterator iter1 = m.find(word1);

	if (iter1 == m.end())
	{
		map<string, float> temp;
		temp.insert(map<string, float>::value_type(word2, freq));
		m.insert(map<string, map<string, float> >::value_type(word1, temp));
	}
	else
	{
		map<string, float>::iterator iter2 = iter1->second.find(word2);

		if (iter2 == iter1->second.end())
		{
			iter1->second.insert(map<string, float>::value_type(word2, freq));
		}
		else
		{
			iter2->second += freq;
		}
	}
}

/************************************************
  collect count
************************************************/
void collectCount(const vector<string>& srcWordVec,
				  const vector<string>& trgWordVec,
				  const map<pair<int, int>, float>& alignment,
				  map<string, map<string, float> >& s2tFreq,
				  map<string, map<string, float> >& t2sFreq)
{
	int i;

	// for each source word
	for (i = 1; i < (int)srcWordVec.size(); i++)
	{
		float count = 1.0;
		map<pair<int, int>, float>::const_iterator iter1;

		for (iter1 = alignment.begin(); iter1 != alignment.end(); iter1++)
		{
			if (iter1->first.first == i)
			{
				count *= 1.0 - iter1->second;
			}

			// ignore zero
			if (count < 1e-7)
			{
				continue;
			}

			updateFreq("$NULL", srcWordVec[i], count, t2sFreq);
		}
	}

	// for each target word
	for (i = 1; i < (int)trgWordVec.size(); i++)
	{
		float count = 1.0;
		map<pair<int, int>, float>::const_iterator iter1;

		for (iter1 = alignment.begin(); iter1 != alignment.end(); iter1++)
		{
			if (iter1->first.second == i)
			{
				count *= 1.0 - iter1->second;
			}

			// ignore zero
			if (count < 1e-7)
			{
				continue;
			}

			updateFreq("$NULL", trgWordVec[i], count, s2tFreq);
		}
	}

	// update rule freq
	map<pair<int, int>, float>::const_iterator iter1;

	for (iter1 = alignment.begin(); iter1 != alignment.end(); iter1++)
	{
		int sp = iter1->first.first,
			tp = iter1->first.second;
		float count = iter1->second;
		string srcWord = srcWordVec[sp],
			   trgWord = trgWordVec[tp];

		updateFreq(srcWord, trgWord, count, s2tFreq);
		updateFreq(trgWord, srcWord, count, t2sFreq);
	}
}

/************************************************
  normalize
************************************************/
void normalize(map<string, map<string, float> >& m)
{
	map<string, map<string, float> >::iterator iter1;

	for (iter1 = m.begin(); iter1 != m.end(); iter1++)
	{
		float sum = 0;
		map<string, float>::iterator iter2;

		for (iter2 = iter1->second.begin(); iter2 != iter1->second.end(); iter2++)
		{
			sum += iter2->second;
		}

		for (iter2 = iter1->second.begin(); iter2 != iter1->second.end(); iter2++)
		{
			iter2->second /= sum;
		}
	}
}

/************************************************
  dump
************************************************/
void dump(map<string, map<string, float> >& m,
		  const char* fileName)
{
	ofstream out(fileName);
	map<string, map<string, float> >::iterator iter1;

	for (iter1 = m.begin(); iter1 != m.end(); iter1++)
	{
		map<string, float>::iterator iter2;

		for (iter2 = iter1->second.begin(); iter2 != iter1->second.end(); iter2++)
		{
			out << iter1->first
				<< " "
				<< iter2->first
				<< " "
				<< iter2->second
				<< endl;
		}
	}

	m.clear();
}

/************************************************
  main function
************************************************/
int main(int argc, char** argv)
{
	// version
	version();

	if (argc != 6)
	{
		cerr << "Usage: matrixBuildTTable srcFile trgFile agtFile s2tTTableFile t2sTTableFile" << endl;
		exit(1);
	}

	ifstream in1(argv[1]),
		     in2(argv[2]),
			 in3(argv[3]);
	ofstream out1(argv[4]),
		     out2(argv[5]);
	string line1,
		   line2,
		   line3;
	map<string, map<string, float> > s2tFreq,  // source to target
		                             t2sFreq;  // target to source

	// line by line
	while (getline(in1, line1) &&
		   getline(in2, line2) &&
		   getline(in3, line3))
	{
		// get sentences
		vector<string> srcWordVec,
			           trgWordVec;
		buildWordVec(line1, srcWordVec);
		buildWordVec(line2, trgWordVec);

		// get alignment
		map<pair<int, int>, float> alignment;
		buildAlignment(line3, alignment);

		// collect count
		collectCount(srcWordVec, trgWordVec, alignment, s2tFreq, t2sFreq);
	}

	// normalize
	normalize(s2tFreq);
	normalize(t2sFreq);

	// dump
	dump(s2tFreq, argv[4]);
	dump(t2sFreq, argv[5]);

	return 0;
}
