#include <iostream>
#include <fstream>
#include <string>

using namespace std;

/************************************************
  version
************************************************/
void version()
{
	cout << "----------------------------------------\n"
		    " genRuleTable v0.2\n"
			" 2010/03/03 - 2010/03/03\n"
			" (c) 2008-2010 Yang Liu\n"
			"----------------------------------------\n";
}

/************************************************
  main function
************************************************/
int main(int argc, char** argv)
{
	// version
	version();

	if (argc != 4)
	{
		cerr << "Usage: genRuleTable table1 table2 finalTable" << endl;
		exit(1);
	}

	ifstream in1(argv[1]),
		     in2(argv[2]);
	ofstream out(argv[3]);
	string line1,
		   line2;

	while (getline(in1, line1) &&
		   getline(in2, line2))
	{
		int spp = line2.find_last_of(' ');

		out << line1
			<< line2.substr(spp, (int)line2.size() - spp)
			<< endl;
	}

	return 0;
}
