#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <algorithm>

using namespace std;

/************************************************
  version
************************************************/
void version()
{
	cout << "----------------------------------------\n"
		    " giza2std v0.2\n"
			" 2010/03/01 - 2010/03/01\n"
			" (c) 2008-2010 Yang Liu\n"
			"----------------------------------------\n";
}

/************************************************
  get lines from GIZA++ output
************************************************/
bool getlines(ifstream& in,
			  int& sentID,
			  float& score,
			  vector<pair<int, int> >& alignment,
			  int type)
{
	string line;

	if (!getline(in, line))
	{
		return false;
	}

	// sentence id
	int spp1 = line.find('(') + 1,
		spp2 = line.find(')', spp1);
	sentID = atoi(line.substr(spp1, spp2 - spp1).c_str());

	// score assigned be GIZA++
	spp1 = line.find(':') + 2;
	spp2 = line.size();
	score = atof(line.substr(spp1, spp2 - spp1).c_str());

	// ignore a line
	getline(in, line);

	// construct an alignment
	getline(in, line);
	alignment.clear();

	spp1 = line.find("})");
	spp2 = spp1 + 3;
	int index = 0;

	spp1 = line.find("({", spp2);

	while (spp1 > 0)
	{
		index++;
		spp2 = line.find("})", spp1 + 2);
		istringstream iss(line.substr(spp1 + 2, spp2 - spp1 - 2).c_str());
		string w;

		while (iss >> w)
		{
			int x = atoi(w.c_str());

			if (type)
			{
				alignment.push_back(pair<int, int>(index, x));
			}
			else
			{
				alignment.push_back(pair<int, int>(x, index));
			}
		}

		spp1 = line.find("({", spp2);
	}

	sort(alignment.begin(), alignment.end());

	return true;
}

/************************************************
  dump alignments to a file
************************************************/
void dump(int sentID,
		  vector<float>& scoreVec,
		  vector<vector<pair<int, int> > >& alignmentVec,
		  ofstream& out)
{
	out << "<sent id="
		<< sentID
		<< ">\n";

	for (int i = 0; i < (int)alignmentVec.size(); i++)
	{
		out << "<cand score="
			<< scoreVec[i]
			<< ">";

		for (int j = 0; j < (int)alignmentVec[i].size(); j++)
		{
			out << alignmentVec[i][j].first
				<< ":"
				<< alignmentVec[i][j].second;

			if (j != (int)alignmentVec[i].size() - 1)
			{
				out << " ";
			}
		}

		out << "</cand>" << endl;
	}

	out << "</sent>" << endl;

	scoreVec.clear();
	alignmentVec.clear();
}

/************************************************
  main function
************************************************/
int main(int argc, char** argv)
{
	// �汾
	version();

	if (argc != 4)
	{
		cerr << "Usage: giza2std A3File type stdFile\n"
			    "       type: 1 for s2t, 0 for t2s\n";
		exit(1);
	}

	ifstream in(argv[1]);
	int type = atoi(argv[2]);
	ofstream out(argv[3]);
	vector<float> scoreVec;  // score
	vector<vector<pair<int, int> > > alignmentVec;  // alignment
	int sentID,
		lastID = 0;
	float score;
	vector<pair<int, int> > alignment;

	while (getlines(in, sentID, score, alignment, type))
	{
		if (lastID == 0)
		{
			scoreVec.push_back(score);
			alignmentVec.push_back(alignment);
			lastID = sentID;
		}
		else
		{
			if (sentID == lastID)
			{
				scoreVec.push_back(score);
				alignmentVec.push_back(alignment);
			}
			else
			{
				// dump alignments to a file
				dump(lastID, scoreVec, alignmentVec, out);

				scoreVec.push_back(score);
				alignmentVec.push_back(alignment);
				lastID = sentID;
			}
		}
	}

	if (!alignmentVec.empty())
	{
		dump(lastID, scoreVec, alignmentVec, out);
	}

	return 0;
}
