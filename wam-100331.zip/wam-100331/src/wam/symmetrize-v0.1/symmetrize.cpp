#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <set>
#include <cmath>
#include <sstream>
#include <algorithm>
#include <ctime>

using namespace std;

/************************************************
  version
************************************************/
void version()
{
	cout << "----------------------------------------\n"
		    " symmetrize v0.1\n"
			" 2010/03/01 - 2010/03/01\n"
			" (c) 2008-2010 Yang Liu\n"
			"----------------------------------------\n";
}

/************************************************
  get alignments
************************************************/
bool getAlignments(ifstream& in,
		           vector<float>& scoreVec,
				   vector<vector<pair<int, int> > >& alignmentVec)
{
	string line;

	while (getline(in, line))
	{
		if (line.find("<sent") != string::npos)
		{
			scoreVec.clear();
			alignmentVec.clear();
		}
		else if (line.find("<cand") != string::npos)
		{
			// get score
			int spp1 = line.find("score=") + 6,
				spp2 = line.find('>', spp1);
			float score = atof(line.substr(spp1, spp2 - spp1).c_str());
			score = log(score);

			// get alignment
			vector<pair<int, int> > alignment;
			spp1 = spp2 + 1;
			spp2 = line.find("</cand>", spp1);
			istringstream iss(line.substr(spp1, spp2 - spp1).c_str());
			string w;

			while (iss >> w)
			{
				int spp = w.find(':'),
					sp = atoi(w.substr(0, spp).c_str()),
					tp = atoi(w.substr(spp + 1, (int)w.size() - spp - 1).c_str());
				alignment.push_back(pair<int, int>(sp, tp));
			}

			scoreVec.push_back(score);
			alignmentVec.push_back(alignment);
		}
		else if (line.find("</sent>") != string::npos)
		{
			return true;
		}
	}

	return false;
}

/************************************************
  grow-diag-final-and
************************************************/
void grow_diag_final_and(const vector<pair<int, int> >& a11,
		                 const vector<pair<int, int> >& a22,
						 vector<pair<int, int> >& a)
{
	// generate inverse alignments
	vector<pair<int, int> > a1,
	                        a2;
	int i;

	for (i = 0; i < (int)a11.size(); i++)
	{
		a1.push_back(pair<int, int>(a11[i].second, a11[i].first));
	}

	for (i = 0; i < (int)a22.size(); i++)
	{
		a2.push_back(pair<int, int>(a22[i].second, a22[i].first));
	}

	sort(a1.begin(), a1.end());
	sort(a2.begin(), a2.end());

	vector<pair<int, int> > neighbors;

	neighbors.push_back(pair<int, int>(-1, 0));
	neighbors.push_back(pair<int, int>(0, -1));
	neighbors.push_back(pair<int, int>(1, 0));
	neighbors.push_back(pair<int, int>(0, 1));
	neighbors.push_back(pair<int, int>(-1, -1));
	neighbors.push_back(pair<int, int>(-1, 1));
	neighbors.push_back(pair<int, int>(1, -1));
	neighbors.push_back(pair<int, int>(1, 1));

	// coverage
	vector<int> srcCov(1000, 0),
		        trgCov(1000, 0);

	// intersection
	set<pair<int, int> > currentpoints,
		                 unionalignment;
	pair<int, int> point;

	for (i = 0; i < (int)a1.size(); i++)
	{
		unionalignment.insert(a1[i]);

		for (int j = 0; j < (int)a2.size(); j++)
		{
			if (a2[j] == a1[i])
			{
				currentpoints.insert(a2[j]);
				srcCov[a2[j].first] = 1;
				trgCov[a2[j].second] = 1;
				continue;
			}
		}
	}

	for (i = 0; i < (int)a2.size(); i++)
	{
		unionalignment.insert(a2[i]);
	}

	// grow
	int added = 1;

	while (added)
	{
		added = 0;

		set<pair<int, int> >::iterator iter1,
			                           iter2;

		// scan the current alignment
		for (iter1 = currentpoints.begin(); iter1 != currentpoints.end(); iter1++)
		{
			// go over check all neighbors
			for (int i = 0; i < (int)neighbors.size(); i++)
			{
				point.first = iter1->first + neighbors[i].first;
				point.second = iter1->second + neighbors[i].second;

				// does the point in the union alignment?
				iter2 = unionalignment.find(point);

				if (iter2 == unionalignment.end())
				{
					continue;
				}

				// check if it connects at least one uncovered word
				bool src_covered = false,
					 trg_covered = false;

				if (!(srcCov[point.first] && trgCov[point.second]))
				{
					currentpoints.insert(point);
					srcCov[point.first] = 1;
					trgCov[point.second] = 1;
					added = 1;
				}
			}
		}
	}

	// final-and
	for (i = 0; i < (int)a1.size(); i++)
	{
		point = a1[i];

		// check if it connects at least one uncovered word
		if (!srcCov[point.first] && !trgCov[point.second])
		{
			currentpoints.insert(point);
			srcCov[point.first] = 1;
			trgCov[point.second] = 1;
		}
	}

	for (i = 0; i < (int)a2.size(); i++)
	{
		point = a2[i];

		// check if it connects at least one uncovered word
		if (!srcCov[point.first] && !trgCov[point.second])
		{
			currentpoints.insert(point);
			srcCov[point.first] = 1;
			trgCov[point.second] = 1;
		}
	}

	// done
	set<pair<int, int> >::iterator iter;

	for (iter = currentpoints.begin(); iter != currentpoints.end(); iter++)
	{
		a.push_back(pair<int, int>(iter->second, iter->first));
	}

	sort(a.begin(), a.end());
}

/************************************************
  main function
************************************************/
int main(int argc, char** argv)
{
	// version
	version();

	if (argc != 6)
	{
		cerr << "Usage: symmetrize n smooth directNBestFile inverseNBestFile nBestListFile\n";
		exit(1);
	}

	int n = atoi(argv[1]);
	float smooth = atof(argv[2]);

	ifstream in1(argv[3]),
			 in2(argv[4]);
	ofstream out(argv[5]);
	vector<float> scoreVec1,
		          scoreVec2;
	vector<vector<pair<int, int> > > alignmentVec1,
		                             alignmentVec2;
	double sentCount = 0,
		   alignmentCount = 0;
	int	minCount = 0,
		maxCount = 0;

	clock_t tb = clock();

	// sentence by sentence
	while (getAlignments(in1, scoreVec1, alignmentVec1) &&
		   getAlignments(in2, scoreVec2, alignmentVec2))
	{
		sentCount++;

		vector<vector<pair<int, int> > > nBestList;  // unique, ranked n-best symmetric alignemnts
		vector<float> weightVec;  // associated weights after smoothing

		int actual_count = 0,
		    i;

		// enumerate all possible combinations
		for (i = 0; i < (int)alignmentVec1.size() && i < n; i++)
		{
			for (int j = 0; j < (int)alignmentVec2.size() && j < n; j++)
			{
				actual_count++;

				// symmetrization
				vector<pair<int, int> > a;
				grow_diag_final_and(alignmentVec1[i], alignmentVec2[j], a);
				float score = smooth * (scoreVec1[i] + scoreVec2[j]);

				// update
				bool isNew = true;

				for (int k = 0; k < (int)nBestList.size(); k++)
				{
					if (nBestList[k] == a)
					{
						if (score > weightVec[k])
						{
							weightVec[k] = score;
						}

						isNew = false;
						break;
					}
				}

				if (isNew)
				{
					nBestList.push_back(a);
					weightVec.push_back(score);
				}
			}
		}

		// update
		alignmentCount += nBestList.size();

		if (minCount == 0 ||
			nBestList.size() < minCount)
		{
			minCount = nBestList.size();
		}

		if (maxCount == 0 ||
			nBestList.size() > maxCount)
		{
			maxCount = nBestList.size();
		}

		// sort
		for (int pass = 0; pass < (int)nBestList.size() - 1; pass++)
		{
			for (int i = 0; i < (int)nBestList.size() - 1; i++)
			{
				if (weightVec[i] < weightVec[i + 1])
				{
					vector<pair<int, int> > hold1 = nBestList[i];
					float hold2 = weightVec[i];

					nBestList[i] = nBestList[i + 1];
					weightVec[i] = weightVec[i + 1];

					nBestList[i + 1] = hold1;
					weightVec[i + 1] = hold2;
				}
			}
		}

		cout << "(" 
			 << sentCount 
			 << ") " 
			 << nBestList.size() 
			 << " " 
			 << actual_count
			 << endl;

		// dump
		out << "<sent id="
			<< sentCount
			<< ">\n";

		for (i = 0; i < (int)nBestList.size(); i++)
		{
			out << "<alignment id="
				<< i + 1
				<< " score="
				<< weightVec[i]
				<< ">";

			for (int j = 0; j < (int)nBestList[i].size(); j++)
			{
				out << nBestList[i][j].first
					<< ":"
					<< nBestList[i][j].second;

				if (j != (int)nBestList[i].size() - 1)
				{
					out << " ";
				}
			}

			out << "</alignment>" << endl;
		}

		out << "</sent>" << endl;
	}

	clock_t te = clock();

	cout << "\n[time] "
		 << (float)(te - tb) / CLOCKS_PER_SEC
		 << "\n[sent] "
		 << sentCount
		 << "\n[alignemnt] "
		 << alignmentCount
		 << "\n[min] "
		 << minCount
		 << "\n[max] "
		 << maxCount
		 << "\n[average] "
		 << alignmentCount / sentCount
		 << endl;

	return 0;
}
