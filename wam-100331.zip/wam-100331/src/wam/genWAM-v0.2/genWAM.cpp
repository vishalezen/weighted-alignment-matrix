#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <map>

using namespace std;

/************************************************
  version
************************************************/
void version()
{
	cout << "----------------------------------------\n"
		    " genWAM v0.2\n"
			" 2010/03/01 - 2010/03/01\n"
			" (c) 2008-2010 Yang Liu\n"
			"----------------------------------------\n";
}

/************************************************
  update score
************************************************/
void update(map<pair<int, int>, float>& m,
			int sp,
			int tp,
			float score)
{
	pair<int, int> pr(sp, tp);

	map<pair<int, int>, float>::iterator iter = m.find(pr);

	if (iter == m.end())
	{
		m.insert(map<pair<int, int>, float>::value_type(pr, score));
	}
	else
	{
		iter->second += score;
	}
}

/************************************************
  dump alignments to a file
************************************************/
void dump(map<pair<int, int>, float>& m,
		  ofstream& out)
{
	map<pair<int, int>, float>::iterator iter;

	for (iter = m.begin(); iter != m.end(); iter++)
	{
		out << iter->first.first
			<< ":"
			<< iter->first.second
			<< "/"
			<< iter->second
			<< " ";
	}

	out << endl;

	m.clear();
}

/************************************************
  main function
************************************************/
int main(int argc, char** argv)
{
	// version
	version();

	if (argc != 3)
	{
		cerr << "Usage: genWAM n-best matrix" << endl;
		exit(1);
	}

	ifstream in(argv[1]);
	ofstream out(argv[2]);
	map<pair<int, int>, float> wam;
	string line;

	while (getline(in, line))
	{
		if (line.find("<sent") != string::npos)
		{
			wam.clear();
		}
		else if (line.find("<alignment") != string::npos)
		{
			// score
			int spp1 = line.find("score=") + 6,
				spp2 = line.find('>', spp1);
			float score = atof(line.substr(spp1, spp2 - spp1).c_str());

			// wam
			spp1 = spp2 + 1;
			spp2 = line.find('<', spp1);
			istringstream iss(line.substr(spp1, spp2 - spp1).c_str());
			string w;

			while (iss >> w)
			{
				int spp = w.find(':'),
					sp = atoi(w.substr(0, spp).c_str()),
					tp = atoi(w.substr(spp + 1, (int)w.size() - spp - 1).c_str());
				update(wam, sp, tp, score);
			}
		}
		else if (line.find("</sent") != string::npos)
		{
			// dump alignments to a file
			dump(wam, out);
		}
	}

	return 0;
}
