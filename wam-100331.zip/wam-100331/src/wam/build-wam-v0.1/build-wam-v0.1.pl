#!/usr/bin/perl -w

use strict;
use Getopt::Long "GetOptions";

# build-wam-v0.1
# 2010/03/01-2010/03/01
# (c) 2008-2010 Yang Liu

# these variables may have to adapted to local paths
my $GIZA = "/home3/ly/ly/toolkits/GIZA++/GIZA++";
my $MKCLS = "/home3/ly/ly/toolkits/GIZA++/mkcls";
my $PLAIN_2_SNT = "/home3/ly/ly/toolkits/GIZA++/plain2snt.out";
my $SNT_2_COOC = "/home3/ly/ly/toolkits/GIZA++/snt2cooc.out";
my $GIZA_2_STD = "/home3/ly/ly/projects/WAM-Release/src/wam/giza2std-v0.2/giza2std_v0_2";
my $SYMMETRIZE = "/home3/ly/ly/projects/WAM-Release/src/wam/symmetrize-v0.1/symmetrize_v0_1";
my $GET_NBESTLIST = "/home3/ly/ly/projects/WAM-Release/src/wam/getNBestList-v0.2/getNBestList_v0_2";
my $GEN_WAM = "/home3/ly/ly/projects/WAM-Release/src/wam/genWAM-v0.2/genWAM_v0_2";
my $COPY = "cp";
my $REMOVE = "rm";
#------------------------------------------------------

my($_SRC_FILE, $_TRG_FILE, $_N, $_HELP);

$_HELP = 1 unless &GetOptions('src-file=s' => \$_SRC_FILE,
                              'trg-file=s' => \$_TRG_FILE,
                              'n=i' => \$_N,
                              'help' => \$_HELP);

# some arguments are required
&help unless $_SRC_FILE && $_TRG_FILE;
my $___SRC_FILE = $_SRC_FILE;
my $___TRG_FILE = $_TRG_FILE;
my $___N = 10;
$___N = $_N if $_N;

# Step 1: GIZA++ training
print "\nStep 1: GIZA++ training\n";

print "\n[1.1] get two copies\n";
system("$COPY $___SRC_FILE source");
system("$COPY $___TRG_FILE target");

print "\n[1.2] produce snt files\n";
system("$PLAIN_2_SNT source target");

print "\n[1.3] make word classes\n";
system("$MKCLS -c100 -n2 -psource -Vsource.vcb.classes opt");
system("$MKCLS -c100 -n2 -ptarget -Vtarget.vcb.classes opt");

print "\n[1.4] collect co-occurrences from snt files\n";
system("$SNT_2_COOC source.vcb target.vcb source_target.snt > source_target.cooc");
system("$SNT_2_COOC target.vcb source.vcb target_source.snt > target_source.cooc");

print "\n[1.5] run GIZA++\n";
system("$GIZA -S source.vcb -T target.vcb -C source_target.snt -CoocurrenceFile source_target.cooc -nbestalignments 10");
system("$GIZA_2_STD *.A3.finalNBEST 1 s2t_nbest.txt");
system("$REMOVE *.A3.finalNBEST");
system("$GIZA -S target.vcb -T source.vcb -C target_source.snt -CoocurrenceFile target_source.cooc -nbestalignments 10");
system("$GIZA_2_STD *.A3.finalNBEST 0 t2s_nbest.txt");

print "\n[1.6] delete intermediate files\n";
system("$REMOVE *.gizacfg *.final *.finalNBEST *.config *.perp *.vcb *.snt *.cooc *.classes *.cats source target");

# Step 2: Symmetrization
print "\nStep 2: Symmetrization\n";
system("$SYMMETRIZE $___N 1.0 s2t_nbest.txt t2s_nbest.txt gdf_nbest.txt");
system("$REMOVE s2t_nbest.txt t2s_nbest.txt");

#Step 3: Get n-best list
print "\nStep 3: Get n-best list\n";
system("$GET_NBESTLIST $___N gdf_nbest.txt nbest.txt");
system("$REMOVE gdf_nbest.txt");

# Step 4: WAM construction
print "\nStep 4: WAM construction\n";
system("$GEN_WAM nbest.txt wam.txt");
system("$REMOVE nbest.txt");

#help
sub help
{
    my $usage = "Usage: build-wam ...\n\n".
                "Description: build weighted alignment matrices from a bilingual corpus\n\n".
                "Required arguments:\n".
                "  --src-file <src_file>    a file containing source text\n".
                "  --trg-file <trg_file>    a file containing target text\n".
                "Optional arguments:\n".
                "  --n <n=10>               n-best file (default: 10)\n".
                "  --help                   prints this message to STDOUT\n";

    print "$usage";
    exit;
}
