#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <vector>

using namespace std;

/************************************************
  version
************************************************/
void version()
{
	cout << "----------------------------------------\n"
		    " getNBestList v0.2\n"
			" 2010/03/01 - 2010/03/01\n"
			" (c) 2008-2010 Yang Liu\n"
			"----------------------------------------\n";
}

/************************************************
  get alignments
************************************************/
bool getAlignments(ifstream& in,
				   vector<pair<float, string> >& alignments)
{
	alignments.clear();

	string line;

	while (getline(in, line))
	{
		if (line.find("<alignment") != string::npos)
		{
			// score
			int spp1 = line.find("score=") + 6,
				spp2 = line.find('>', spp1);
			float score = atof(line.substr(spp1, spp2 - spp1).c_str());

			// alignment
			spp1 = spp2 + 1;
			spp2 = line.find('<', spp1);
			string alignment = line.substr(spp1, spp2 - spp1);

			// make a pair
			pair<float, string> pr;
			pr.first = score;
			pr.second = alignment;
			alignments.push_back(pr);
		}
		else if (line.find("</sent>") != string::npos)
		{
			return true;
		}
	}

	return false;
}

/************************************************
  get top-n alignemnts
************************************************/
void top_n(vector<pair<float, string> >& alignments,
		   int n)
{
	vector<pair<float, string> > hold = alignments;
	alignments.clear();
	int i;

	for (i = 0; i < (int)hold.size() && i < n; i++)
	{
		alignments.push_back(hold[i]);
	}

	// calculate the maximal score
	float sum = 0,
		  max_score = 0;

	for (i = 0; i < (int)alignments.size(); i++)
	{
		if (i == 0 ||
			alignments[i].first > max_score)
		{
			max_score = alignments[i].first;
		}
	}

	for (i = 0; i < (int)alignments.size(); i++)
	{
		sum += exp(alignments[i].first - max_score);
	}

	sum = log(sum);

	sum += max_score;

	// update
	for (i = 0; i < (int)alignments.size(); i++)
	{
		alignments[i].first = exp(alignments[i].first - sum);
	}
}

/************************************************
  dump to file
************************************************/
void dump(vector<pair<float, string> >& alignments,
		  long sentID,
		  ofstream& out)
{
	out << "<sent id="
		<< sentID
		<< ">"
		<< endl;

	for (int i = 0; i < (int)alignments.size(); i++)
	{
		out << "<alignment id="
			<< i + 1
			<< " score="
			<< alignments[i].first
			<< ">"
			<< alignments[i].second
			<< "</alignment>"
			<< endl;
	}

	out << "</sent>"
		<< endl;

	alignments.clear();
}

/************************************************
  main function
************************************************/
int main(int argc, char** argv)
{
	// version
	version();

	if (argc != 4)
	{
		cerr << "Usage: getNBestList n input output" << endl;
		exit(1);
	}

	int n = atoi(argv[1]);
	ifstream in(argv[2]);
	ofstream out(argv[3]);
	vector<pair<float, string> > alignments;
	long sentID = 0,
		 minCount = 10000,
		 maxCount = 0,
		 totalCount = 0;

	while (getAlignments(in, alignments))
	{
		sentID++;

		// get top-n alignments
		top_n(alignments, n);

		// min and max
		int count = alignments.size();

		if (count < minCount)
		{
			minCount = count;
		}

		if (count > maxCount)
		{
			maxCount = count;
		}

		totalCount += count;

		// dump
		dump(alignments, sentID, out);
	}

	cout << "[sentCount] "
		 << sentID
		 << "\n[minCount] "
		 << minCount
		 << "\n[maxCount] "
		 << maxCount
		 << "\n[totalCount] "
		 << totalCount
		 << "\n[averageCount] "
		 << (double) totalCount / sentID
		 << endl;

	return 0;
}
