#!/usr/bin/perl -w

use strict;
use Getopt::Long "GetOptions";

# extract-phrase v0.4
# 2010/03/02 - 2010/03/02
# 2008-2010 (c) Yang Liu

my $EXTRACTOR = "/home3/ly/ly/projects/WAM-Release/src/phrase/extractor-v0.5/extractor_v0_5";
my $MERGER = "/home3/ly/ly/projects/WAM-Release/src/phrase/merger-v0.2/merger_v0_2";
my $REVERSER = "/home3/ly/ly/projects/WAM-Release/src/phrase/reverser-v0.2/reverser_v0_2";
my $NORMALIZER = "/home3/ly/ly/projects/WAM-Release/src/phrase/normalizer-v0.2/normalizer_v0_2";
my $BUILD_TTABLE = "/home3/ly/ly/projects/WAM-Release/src/phrase/buildTTable-v0.3/buildTTable_v0_3";
my $SCORER = "/home3/ly/ly/projects/WAM-Release/src/phrase/scorer-v0.2/scorer_v0_2";
my $REMOVER = "/home3/ly/ly/projects/WAM-Release/src/phrase/remover-v0.2/remover_v0_2";
my $LS = "ls";  # Windows: "dir /B" Linux: "ls"
my $RM = "rm";  # Windows: "del"    Linux: "rm"

my($_SRC_FILE, $_TRG_FILE, $_AGT_FILE, $_MAX_CAPACITY, $_MAX_PHRASE_LEN,
		$_PRUNING_THRESHOLD, $_RULE_TABLE_FILE, $_HELP);

$_HELP = 1 unless &GetOptions('src-file=s' => \$_SRC_FILE,
		                          'trg-file=s' => \$_TRG_FILE,
							                'agt-file=s' => \$_AGT_FILE,
							                'max-capacity=i' => \$_MAX_CAPACITY,
							                'max-phrase-len=i' => \$_MAX_PHRASE_LEN,
							                'pruning-threshold=f' => \$_PRUNING_THRESHOLD,
							                'rule-table-file=s' => \$_RULE_TABLE_FILE,
							                'help' => \$_HELP);

# check required arguments
&help unless $_SRC_FILE && $_TRG_FILE && $_AGT_FILE && $_RULE_TABLE_FILE;
my $___SRC_FILE = $_SRC_FILE;
my $___TRG_FILE = $_TRG_FILE;
my $___AGT_FILE = $_AGT_FILE;
my $___RULE_TABLE_FILE = $_RULE_TABLE_FILE;

# set optional arguments
my $___MAX_CAPACITY = 1000000;
my $___MAX_PHRASE_LEN = 10;
my $___PRUNING_THRESHOLD = 0.1;

$___MAX_CAPACITY = $_MAX_CAPACITY if $_MAX_CAPACITY;
$___MAX_PHRASE_LEN = $_MAX_PHRASE_LEN if $_MAX_PHRASE_LEN;
$___PRUNING_THRESHOLD = $_PRUNING_THRESHOLD if $_PRUNING_THRESHOLD;

# training
print "\nStep 1: extract bilingual phrases\n";
system("$EXTRACTOR -s $___SRC_FILE -t $___TRG_FILE -a $___AGT_FILE -c $___MAX_CAPACITY -l $___MAX_PHRASE_LEN -p $___PRUNING_THRESHOLD");

print "\nStep 2: merge rule frequency files\n";
`$LS ruleFreq_*.txt > fileList.txt`;
system("$MERGER fileList.txt ruleFreq.txt");
`$RM ruleFreq_*.txt fileList.txt`;

print "\nStep 3: normalize\n";
system("$NORMALIZER ruleFreq.txt ruleTable1.txt");

print "\nStep 4: reverse\n";
system("$REVERSER ruleFreq.txt $___MAX_CAPACITY");
`$RM ruleFreq.txt`;

print "\nStep 5: merger reversed rule frequency files\n";
`$LS r_ruleFreq_*.txt > fileList.txt`;
system("$MERGER fileList.txt r_ruleFreq.txt");
`$RM r_ruleFreq_*.txt fileList.txt`;

print "\nStep 6: normalize\n";
system("$NORMALIZER r_ruleFreq.txt r_ruleTable.txt");
`$RM r_ruleFreq.txt`;

print "\nStep 7: reverse\n";
system("$REVERSER r_ruleTable.txt $___MAX_CAPACITY");
`$RM r_ruleTable.txt`;

print "\nStep 8: merge reversed rule frequency files\n";
`$LS r_ruleFreq_*.txt > fileList.txt`;
system("$MERGER fileList.txt ruleTable2.txt");
`$RM r_ruleFreq_*.txt fileList.txt`;

print "\nStep 10: build ttable\n";
system("$BUILD_TTABLE $___SRC_FILE $___TRG_FILE $___AGT_FILE tTable_s2t.txt tTable_t2s.txt");

print "\nStep 11: generate final rule table\n";
system("$SCORER ruleTable1.txt ruleTable2.txt tTable_s2t.txt tTable_t2s.txt ruleTable3.txt");
`$RM ruleTable1.txt ruleTable2.txt tTable_s2t.txt tTable_t2s.txt`;

print "\nStep 12: remove alignments\n";
system("$REMOVER ruleTable3.txt $___RULE_TABLE_FILE");
`$RM ruleTable3.txt`;

# help
sub help
{
	my $usage="Usage: extract-phrase [--help] --src-file <src_file> --trg-file
		<trg_file> --agt-file <agt_file> --rule-table-file
		<rule_table_file>\n\n".
		"Required arguments:\n".
		"  --src-file <src_file>             specify source file\n".
		"  --trg-file <trg_file>             specify target file\n".
		"  --agt-file <agt-file>             specify alignment file\n".
		"  --rule-table-file <rt-file>       specify rule table file\n".
		"\nOptional arguments:\n".
		"  --max-capacity <default: 1000000> 					specify maximal capacity\n".
		"  --max-phrase-len <default: 10>    					specify maximal phrase length\n".
		"  --pruning-threshold <default:0.1> 					specify pruning threshold\n".
		"  --help                            					print this message to STDOUT\n";

	print "$usage";
	exit;
}
