#include <fstream>
#include <sstream>
#include "Rule.h"

/************************************************
  version
************************************************/
void version()
{
	cout << "----------------------------------------\n"
		    " normalizer v0.2\n"
			" 2010/03/02 - 2010/03/02\n"
			" (c) 2008-2010 Yang Liu\n"
			"----------------------------------------\n";
}

/************************************************
  dump
************************************************/
void dump(ofstream& out,
		  map<Rule, float>& m)
{
	float sum = 0;

	map<Rule, float>::iterator iter;

	for (iter = m.begin(); iter != m.end(); iter++)
	{
		sum += iter->second;
	}

	for (iter = m.begin(); iter != m.end(); iter++)
	{
		out << iter->first
			<< "||| "
			<< iter->second / sum
			<< endl;
	}

	m.clear();
}

/************************************************
  main function
************************************************/
int main(int argc, char** argv)
{
	// version
	version();

	if (argc != 3)
	{
		cerr << "Usage: normalize input output" << endl;
		exit(1);
	}

	ifstream in(argv[1]);
	ofstream out(argv[2]);
	map<Rule, float> m;
	string line,
		   lastSrcPhrase;

	while (getline(in, line))
	{
		if (line.find("|||") == string::npos)
		{
			continue;
		}

		// source phrase
		int spp1 = 0,
			spp2 = line.find(" ||| ", spp1);
		string srcPhrase = line.substr(spp1, spp2 - spp1);

		// target phrase
		spp1 = spp2 + 5;
		spp2 = line.find(" ||| ", spp1);
		string trgPhrase = line.substr(spp1, spp2 - spp1);

		// alignment
		spp1 = spp2 + 5;
		spp2 = line.find(" ||| ", spp1);
		map<pair<int, int>, float> alignment;
		istringstream iss(line.substr(spp1, spp2 - spp1).c_str());
		string w;

		while (iss >> w)
		{
			int spp1 = w.find(':'),
			    spp2 = w.find('/'),
				sp = atoi(w.substr(0, spp1).c_str()),
				tp = atoi(w.substr(spp1 + 1, spp2 - spp1 - 1).c_str());
			float prob = atof(w.substr(spp2 + 1, (int)w.size() - spp2 - 1).c_str());

			alignment.insert(map<pair<int, int>, float>::value_type(pair<int, int>(sp, tp), prob));
		}
				
		// frequency
		spp1 = spp2 + 5;
		spp2 = line.size();
		float freq = atof(line.substr(spp1, spp2 - spp1).c_str());

		Rule r;
		r.srcPhrase = srcPhrase;
		r.trgPhrase = trgPhrase;
		r.alignment = alignment;

		if (lastSrcPhrase == "")
		{
			m.insert(map<Rule, float>::value_type(r, freq));
			lastSrcPhrase = srcPhrase;
		}
		else
		{
			if (srcPhrase == lastSrcPhrase)
			{
				m.insert(map<Rule, float>::value_type(r, freq));
			}
			else
			{
				// dump
				dump(out, m);
				m.insert(map<Rule, float>::value_type(r, freq));
				lastSrcPhrase = srcPhrase;
			}
		}
	}

	if (!m.empty())
	{
		// dump
		dump(out, m);
	}

	return 0;
}
