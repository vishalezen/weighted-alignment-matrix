#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <vector>
#include <sstream>

using namespace std;

/************************************************
  version
************************************************/
void version()
{
	cout << "----------------------------------------\n"
		    " buildTTable v0.3\n"
			" 2010/03/02 - 2010/03/02\n"
			" (c) 2008-2010 Yang Liu\n"
			"----------------------------------------\n";
}

/************************************************
  get word vector
************************************************/
void getWordVec(const string& line,
				vector<string>& wordVec)
{
	wordVec.clear();
	wordVec.push_back("$NULL");

	istringstream iss(line.c_str());
	string w;

	while (iss >> w)
	{
		wordVec.push_back(w);
	}
}

/************************************************
  get word alignment
************************************************/
void getAlignment(const string& line,
				  map<pair<int, int>, float>& alignment)
{
	alignment.clear();
	
	istringstream iss(line.c_str());
	string w;

	while (iss >> w)
	{
		int spp1 = w.find(':'),
			spp2 = w.find('/'),
			sp = atoi(w.substr(0, spp1).c_str()),
			tp = atoi(w.substr(spp1 + 1, spp2 - spp1 - 1).c_str());
		float prob = atof(w.substr(spp2 + 1, (int)w.size() - spp2 - 1).c_str());
		alignment.insert(map<pair<int, int>, float>::value_type(pair<int, int>(sp, tp), prob));
	}
}

/************************************************
  main function
************************************************/
int main(int argc, char** argv)
{
	// version
	version();

	if (argc != 6)
	{
		cerr << "Usage: buildTTable source target alignment s2tTTable t2sTTable" << endl;
		exit(1);
	}

	ifstream in1(argv[1]),
			 in2(argv[2]),
			 in3(argv[3]);
	ofstream out1(argv[4]),
			 out2(argv[5]);
	string line1,
		   line2,
		   line3;
	map<string, map<string, float> > s2tFreq,  // source to target
		                             t2sFreq;  // target to source
	map<string, float> sNULLFreq,  // source null
		               tNULLFreq;  // target null

	// line by line
	while (getline(in1, line1) &&
		   getline(in2, line2) &&
		   getline(in3, line3))
	{
		// source and target sentence
		vector<string> srcWordVec,
			           trgWordVec;
		getWordVec(line1, srcWordVec);
		getWordVec(line2, trgWordVec);

		// weighted matrix
		map<pair<int, int>, float> alignment;
		getAlignment(line3, alignment);

		// sNULLFreq
		int i;

		for (i = 1; i < (int)srcWordVec.size(); i++)
		{
			float count = 1.0;

			map<pair<int, int>, float>::iterator iter1;

			for (iter1 = alignment.begin(); iter1 != alignment.end(); iter1++)
			{
				if (iter1->first.first == i)
				{
					count *= 1.0 - iter1->second; 
				}
			}
			
			// ignore zero
			if (count < 1e-7)
			{
				continue;
			}

			// update sNULLFreq
			map<string, float>::iterator iter2 = sNULLFreq.find(srcWordVec[i]);

			if (iter2 == sNULLFreq.end())
			{
				sNULLFreq.insert(map<string, float>::value_type(srcWordVec[i], count));
			}
			else
			{
				iter2->second += count;
			}
		}

		// update tNULLFreq
		for (i = 1; i < (int)trgWordVec.size(); i++)
		{
			float count = 1.0;

			map<pair<int, int>, float>::iterator iter1;

			for (iter1 = alignment.begin(); iter1 != alignment.end(); iter1++)
			{
				if (iter1->first.second == i)
				{
					count *= 1.0 - iter1->second;
				}
			}
			
			// ignore zero
			if (count < 1e-7)
			{
				continue;
			}

			// update tNULLFreq
			map<string, float>::iterator iter2 = tNULLFreq.find(trgWordVec[i]);

			if (iter2 == tNULLFreq.end())
			{
				tNULLFreq.insert(map<string, float>::value_type(trgWordVec[i], count));
			}
			else
			{
				iter2->second += count;
			}
		}

		// update s2t and t2s
		map<pair<int, int>, float>::iterator iter1;

		for (iter1 = alignment.begin(); iter1 != alignment.end(); iter1++)
		{
			int sp = iter1->first.first,
				tp = iter1->first.second;
			float count = iter1->second;
			string srcWord = srcWordVec[sp],
				   trgWord = trgWordVec[tp];

			// s2t
			map<string, map<string, float> >::iterator iter2 = s2tFreq.find(srcWord);

			if (iter2 == s2tFreq.end())
			{
				map<string, float> m;
				m.insert(map<string, float>::value_type(trgWord, count));
				s2tFreq.insert(map<string, map<string, float> >::value_type(srcWord, m));
			}
			else
			{
				map<string, float>::iterator iter3 = iter2->second.find(trgWord);

				if (iter3 == iter2->second.end())
				{
					iter2->second.insert(map<string, float>::value_type(trgWord, count));
				}
				else
				{
					iter3->second += count;
				}
			}

			// t2s
			iter2 = t2sFreq.find(trgWord);

			if (iter2 == t2sFreq.end())
			{
				map<string, float> m;
				m.insert(map<string, float>::value_type(srcWord, count));
				t2sFreq.insert(map<string, map<string, float> >::value_type(trgWord, m));
			}
			else
			{
				map<string, float>::iterator iter3 = iter2->second.find(srcWord);

				if (iter3 == iter2->second.end())
				{
					iter2->second.insert(map<string, float>::value_type(srcWord, count));
				}
				else
				{
					iter3->second += count;
				}
			}
		}
	}

	// consider null
	s2tFreq.insert(map<string, map<string, float> >::value_type("$NULL", tNULLFreq));
	t2sFreq.insert(map<string, map<string, float> >::value_type("$NULL", sNULLFreq));

    // normalize
	map<string, map<string, float> >::iterator iter1;

	for (iter1 = s2tFreq.begin(); iter1 != s2tFreq.end(); iter1++)
	{
		float sum = 0;

		map<string, float>::iterator iter2;

		for (iter2 = iter1->second.begin(); iter2 != iter1->second.end(); iter2++)
		{
			sum += iter2->second;
		}

		for (iter2 = iter1->second.begin(); iter2 != iter1->second.end(); iter2++)
		{
			iter2->second /= sum;
		}
	}

	for (iter1 = t2sFreq.begin(); iter1 != t2sFreq.end(); iter1++)
	{
		float sum = 0;

		map<string, float>::iterator iter2;

		for (iter2 = iter1->second.begin(); iter2 != iter1->second.end(); iter2++)
		{
			sum += iter2->second;
		}

		for (iter2 = iter1->second.begin(); iter2 != iter1->second.end(); iter2++)
		{
			iter2->second /= sum;
		}
	}

	// dump
	for (iter1 = s2tFreq.begin(); iter1 != s2tFreq.end(); iter1++)
	{
		map<string, float>::iterator iter2;

		for (iter2 = iter1->second.begin(); iter2 != iter1->second.end(); iter2++)
		{
			out1 << iter1->first
				 << " "
				 << iter2->first
				 << " "
				 << iter2->second
				 << endl;
		}
	}

	for (iter1 = t2sFreq.begin(); iter1 != t2sFreq.end(); iter1++)
	{
		map<string, float>::iterator iter2;

		for (iter2 = iter1->second.begin(); iter2 != iter1->second.end(); iter2++)
		{
			out2 << iter1->first
				 << " "
				 << iter2->first
				 << " "
				 << iter2->second
				 << endl;
		}
	}

	return 0;
}

