#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>

using namespace std;

/************************************************
  version
************************************************/
void version()
{
	cout << "----------------------------------------\n"
		    " remover v0.2\n"
			" 2010/03/02 - 2010/03/02\n"
			" (c) 2008-2010 Yang Liu\n"
			"----------------------------------------\n";
}

/************************************************
  dump
************************************************/
void dump(const string& lastPhrasePair,
		  vector<string>& lineVec,
		  ofstream& out)
{
	float pts = 0,
		  lts = 0,
		  pst = 0,
		  lst = 0;

	for (int i = 0; i < (int)lineVec.size(); i++)
	{
		string line = lineVec[i];

		int spp1 = 0,
			spp2 = line.find(" ||| ", spp1);
		spp1 = spp2 + 5;
		spp2 = line.find(" ||| ", spp1);
		spp1 = spp2 + 5;
		spp2 = line.find(" ||| ", spp1);
		spp1 = spp2 + 5;
		spp2 = line.size();
		istringstream iss(line.substr(spp1, spp2 - spp1).c_str());
		string w1, w2, w3, w4;
		iss >> w1 >> w2 >> w3 >> w4;

		float p1 = atof(w1.c_str()),
			  p2 = atof(w2.c_str()),
			  p3 = atof(w3.c_str()),
			  p4 = atof(w4.c_str());

		pts += p1;

		if (p2 > lts)
		{
			lts = p2;
		}

		pst += p3;

		if (p4 > lst)
		{
			lst = p4;
		}
	}

	lineVec.clear();

	out << lastPhrasePair 
		<< " ||| "
		<< pts
		<< " "
		<< lts
		<< " "
		<< pst
		<< " "
		<< lst
		<< endl;
}

/************************************************
  main function
************************************************/
int main(int argc, char**argv)
{
	// version
	version();

	if (argc != 3)
	{
		cerr << "Usage: remover input output" << endl;
		exit(1);
	}

	ifstream in(argv[1]);
	ofstream out(argv[2]);
	string line,
		   lastPhrasePair;
	vector<string> lineVec;

	while (getline(in,line))
	{
		if (line.find("|||") == string::npos)
		{
			continue;
		}

		// phrase pair
		int spp1 = 0,
			spp2 = line.find(" ||| ", spp1);
		spp1 = spp2 + 5;
		spp2 = line.find(" ||| ", spp1);
		string phrasePair = line.substr(0, spp2);

		if (lastPhrasePair.empty())
		{
			lineVec.push_back(line);
			lastPhrasePair = phrasePair;
		}
		else
		{
			if (phrasePair == lastPhrasePair)
			{
				lineVec.push_back(line);
			}
			else
			{
				// dump
				dump(lastPhrasePair, lineVec, out);

				// get new phrase pair
				lineVec.push_back(line);
				lastPhrasePair = phrasePair;
			}
		}
	}

	// dump
	if (!lineVec.empty())
	{
		dump(lastPhrasePair, lineVec, out);
	}

	return 0;
}
