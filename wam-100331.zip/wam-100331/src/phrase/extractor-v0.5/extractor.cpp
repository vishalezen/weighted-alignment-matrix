#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <ctime>
#include "Matrix.h"
#include "Rule.h"

/************************************************
  version
************************************************/
void version()
{
	cout << "----------------------------------------\n"
		    " extractor v0.5\n"
			" 2010/03/02 - 2010/03/02\n"
			" (c) 2008-2010 Yang Liu\n"
			"----------------------------------------\n";
}

/************************************************
  help
************************************************/
void help()
{
	cout << "Usage: extractor [-h] -s <src_file> -t <trg_file> -a <agt_file>\n\n"
		    "Required arguments:\n"
			"  -s <src_file> is a file containing source texts\n"
			"  -t <trg_file> is a file containing target texts\n"
			"  -a <agt_file> is a file containing word alignments\n"
			"\n"
			"Optional arguments:\n"
			"  -c [1, +00)   specify maximal number of rules stored in memory (default: 10,000,000)\n"
			"  -l [1, +00)   specify maximal length of a source/target phrase (default: 10)\n"
			"  -p [0, 1]     specify pruning threshold (default: 0.1)\n"
			"  -h            prints this help message to STDOUT\n"
			"\n";

	exit(1);
}

/************************************************
  get a sentence
************************************************/
void getSent(const string& line,
			 vector<string>& sent)
{
	sent.clear();
	sent.push_back("$NULL");

	istringstream iss(line.c_str());
	string w;

	while (iss >> w)
	{
		sent.push_back(w);
	}
}

/************************************************
  dump rules to file
************************************************/
void dump(map<Rule, float>& ruleFreq,
		  const char* fileName)
{
	ofstream out(fileName);

	map<Rule, float>::iterator iter;

	for (iter = ruleFreq.begin(); iter != ruleFreq.end(); iter++)
	{
		
		out << iter->first
			<< "||| "
			<< iter->second
			<< endl;
	}

	ruleFreq.clear();
}

/************************************************
  update rule frequency
************************************************/
void updateRuleFreq(map<Rule, float>& ruleFreq,
				    const Rule& r,
					float freq)
{
	map<Rule, float>::iterator iter = ruleFreq.find(r);

	if (iter == ruleFreq.end())
	{
		ruleFreq.insert(map<Rule, float>::value_type(r, freq));
	}
	else
	{
		iter->second += freq;
	}
}

void updateRuleFreq(map<Rule, float>& ruleFreq,
				  	const map<Rule, float>& rf)
{
	map<Rule, float>::const_iterator iter;

	for (iter = rf.begin(); iter != rf.end(); iter++)
	{
		updateRuleFreq(ruleFreq, iter->first, iter->second);
	}
}

/************************************************
  extract phrases
************************************************/
void extract(const vector<string>& srcSent,
			 const vector<string>& trgSent,
			 const Matrix& matrix,
			 int max_phrase_len,
			 float pruning_threshold,
			 map<Rule, float>& ruleFreq)
{
	// enumerate all source spans
	for (int src_begin = 1; src_begin < (int)srcSent.size(); src_begin++)
	{
		for (int src_end = src_begin; src_end < (int)srcSent.size() && src_end - src_begin < max_phrase_len; src_end++)
		{
			// find the tight target span
			int begin = 0,
				end = 0;
			matrix.getTrgSpan(src_begin, src_end, begin, end);

			if (begin == 0 ||
				end == 0)
			{
				continue;
			}

			// source phrase
			string srcPhrase;
			int i;

			for (i = src_begin; i <= src_end; i++)
			{
				srcPhrase += srcSent[i];

				if (i != src_end)
				{
					srcPhrase += " ";
				}
			}

			// boundary extension on the target side
			for (int length = 1; length <= max_phrase_len; length++)
			{
				for (int trg_begin = begin < length ? 1 : begin - length + 1;
				     trg_begin <= end && trg_begin + length - 1 < (int)trgSent.size(); 
					 trg_begin++)
				{
					int trg_end = trg_begin + length - 1;

					// frequency
					float freq = matrix.getCount(src_begin, src_end, trg_begin, trg_end, (int)srcSent.size() - 1, (int)trgSent.size() - 1);

					// discarded if below the threshold
					if (freq < pruning_threshold)
					{
						continue;
					}

					// alignment within the phrase pair
					map<pair<int, int>, float> sub_alignment;
					matrix.getSubAlignment(src_begin, src_end, trg_begin, trg_end, sub_alignment);

					// target phrase
					string trgPhrase;

					for (int j = trg_begin; j <= trg_end; j++)
					{
						trgPhrase += trgSent[j];

						if (j != trg_end)
						{
							trgPhrase += " ";
						}
					}
					
					Rule r;
					r.srcPhrase = srcPhrase;
					r.trgPhrase = trgPhrase;
					r.alignment = sub_alignment;

					// update rule frequency
					updateRuleFreq(ruleFreq, r, freq);
				}
			}
		}
	}
}

/************************************************
  main function
************************************************/
int main(int argc, char** argv)
{
	// version
	version();

	// analyze command line arguments
	string srcFileName,
		   trgFileName,
		   agtFileName;
	long max_capacity = 10000000;
	int max_phrase_len = 10;
	float pruning_threshold = 0.1;

	for (int i = 1; i < argc; i++)
	{
		if (string(argv[i]) == "-s")
		{
			srcFileName = argv[++i];
		}
		else if (string(argv[i]) == "-t")
		{
			trgFileName = argv[++i];
		}
		else if (string(argv[i]) == "-a")
		{
			agtFileName = argv[++i];
		}
		else if (string(argv[i]) == "-c")
		{
			max_capacity = (long)atof(argv[++i]);
		}
		else if (string(argv[i]) == "-l")
		{
			max_phrase_len = atoi(argv[++i]);
		}
		else if (string(argv[i]) == "-p")
		{
			pruning_threshold = atof(argv[++i]);
		}
		else
		{
			help();
		}
	}

	// check required arguments
	if (srcFileName.empty() ||
		trgFileName.empty() ||
		agtFileName.empty())
	{
		help();
	}

	ifstream in1(srcFileName.c_str()),
		     in2(trgFileName.c_str()),
			 in3(agtFileName.c_str());
	string line1,
		   line2,
		   line3;
	long count = 0;  // sentence count
	double wordCount = 0;  // word count
	int fileID = 0;  // file id
	map<Rule, float> globalRuleFreq;  // global rule frequency

	clock_t tb = clock();

	while (getline(in1, line1) &&
		   getline(in2, line2) &&
		   getline(in3, line3))
	{
		// source and target sentences
		vector<string> srcSent,
			           trgSent;
		getSent(line1, srcSent);
		getSent(line2, trgSent);

		wordCount += srcSent.size() + trgSent.size() - 2;

		// weighted matrix
		Matrix matrix(line3);

		// extract phrases
		map<Rule, float> localRuleFreq;  // local rule frequency

		extract(srcSent, 
			    trgSent, 
				matrix, 
				max_phrase_len, 
				pruning_threshold,
				localRuleFreq);

		// update global rule frequency
		updateRuleFreq(globalRuleFreq, localRuleFreq);

		cout << "("
			 << ++count
			 << ") "
			 << localRuleFreq.size()
			 << " "
			 << globalRuleFreq.size()
			 << endl;

		if (globalRuleFreq.size() > max_capacity)
		{
			fileID++;
			char fileName[100];
			sprintf(fileName, "ruleFreq_%d.txt", fileID);
			dump(globalRuleFreq, fileName);
		}
	}

	if (!globalRuleFreq.empty())
	{
		fileID++;
		char fileName[100];
		sprintf(fileName, "ruleFreq_%d.txt", fileID);
		dump(globalRuleFreq, fileName);
	}

	clock_t te = clock();

	double total_time = (double)(te - tb) / CLOCKS_PER_SEC;

	// record the extracting speed
	ofstream out("speed.txt");

	out << "[time] "
		<< total_time
		<< "\n[average time] "
		<< total_time / count
		<< "\n[speed] "
		<< wordCount / total_time
		<< endl;

	return 0;
}
