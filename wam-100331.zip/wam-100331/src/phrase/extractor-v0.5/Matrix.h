#ifndef MATRIX_H
#define MATRIX_H

#include <iostream>
#include <map>
#include <string>

using namespace std;

class Matrix
{
	// overload <<
	friend ostream& operator<<(ostream& out, const Matrix& right);
public:
	/* member functions */
	// constructor
	Matrix();
	Matrix(const string& line);
	// get fractional count
	float getCount(int src_begin,
		           int src_end,
				   int trg_begin,
				   int trg_end,
				   int srcSentLen,
				   int trgSentLen) const;
	// get sub alignment
	void getSubAlignment(int src_begin,
		                 int src_end,
						 int trg_begin,
						 int trg_end,
						 map<pair<int, int>, float>& sub_alignment) const;
	// get target span
	void getTrgSpan(int src_begin,
		            int src_end,
					int& trg_begin,
					int& trg_end) const;
	
private:
	/* data members */
	map<pair<int, int>, float> matrix;  // weighted matrix
};

#endif
