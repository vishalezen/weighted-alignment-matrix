#include <sstream>
#include <cmath>
#include "Matrix.h"

/************************************************
  constructor
************************************************/
Matrix::Matrix()
{
}

Matrix::Matrix(const string& line)
{
	istringstream iss(line.c_str());
	string w;

	while (iss >> w)
	{
		int spp1 = w.find(':'),
			spp2 = w.find('/'),
			sp = atoi(w.substr(0, spp1).c_str()),
			tp = atoi(w.substr(spp1 + 1, spp2 - spp1 - 1).c_str());
		float prob = atof(w.substr(spp2 + 1, (int)w.size() - spp2 - 1).c_str());

		// ignore points whose prob is lower than 0.0001
		if (prob < 0.0001)
		{
			continue;
		}

		matrix.insert(map<pair<int, int>, float>::value_type(pair<int, int>(sp, tp), 1.0 - prob));
	}
}

/************************************************
  overload <<
************************************************/
ostream& operator<<(ostream& out, const Matrix& right)
{
	map<pair<int, int>, float>::const_iterator iter;

	for (iter = right.matrix.begin(); iter != right.matrix.end(); iter++)
	{
		out << iter->first.first
			<< ":"
			<< iter->first.second
			<< "/"
			<< iter->second
			<< " ";
	}

	return out;
}

/************************************************
  get fractional count
************************************************/
float Matrix::getCount(int src_begin,
		               int src_end,
				       int trg_begin,
				       int trg_end,
				       int srcSentLen,
				       int trgSentLen) const
{
	float  inside_count = 1.0,
		   outside_count = 1.0;
	bool inside_count_done = false;

	map<pair<int, int>, float>::const_iterator iter;

	for (iter = matrix.begin(); iter != matrix.end(); iter++)
	{
		int i = iter->first.first,
			j = iter->first.second;

		// inside count
		if (!inside_count_done &&
			i >= src_begin &&
			i <= src_end &&
			j >= trg_begin &&
			j <= trg_end)
		{
			inside_count *= iter->second;

			// stop if it is zero
			if (fabs(inside_count) < 1e-7)
			{
				inside_count_done = true;
			}
		}

		// outside count
		if (i >= src_begin &&
			i <= src_end &&
			(j < trg_begin ||
			 j > trg_end) ||
			(i < src_begin ||
			 i > src_end) &&
			j >= trg_begin &&
			j <= trg_end)
		{
			outside_count *= iter->second;

			// stop if it is zero
			if (fabs(outside_count) < 1e-7)
			{
				return 0;
			}
		}
	}

	return (1.0 - inside_count) * outside_count;
}

/************************************************
  get sub alignments
************************************************/
void Matrix::getSubAlignment(int src_begin,
		                     int src_end,
				    		 int trg_begin,
					    	 int trg_end,
						     map<pair<int, int>, float>& sub_alignment) const
{
	sub_alignment.clear();

	map<pair<int, int>, float>::const_iterator iter;

	for (iter = matrix.begin(); iter != matrix.end(); iter++)
	{
		int sp = iter->first.first,
			tp = iter->first.second;

		if (sp >= src_begin &&
			sp <= src_end &&
			tp >= trg_begin &&
			tp <= trg_end)
		{
			int new_sp = sp - src_begin + 1,
				new_tp = tp - trg_begin + 1;
			sub_alignment.insert(map<pair<int, int>, float>::value_type(pair<int, int>(new_sp, new_tp), 1.0 - iter->second));
		}
	}
}

/************************************************
  get target span
************************************************/
void Matrix::getTrgSpan(int src_begin,
		                int src_end,
				    	int& trg_begin,
					    int& trg_end) const
{
	trg_begin = 0;
	trg_end = 0;

	map<pair<int, int>, float>::const_iterator iter;

	for (iter = matrix.begin(); iter != matrix.end(); iter++)
	{
		if (iter->first.first >= src_begin &&
			iter->first.first <= src_end)
		{
			if (trg_begin == 0 ||
				iter->first.second < trg_begin)
			{
				trg_begin = iter->first.second;
			}

			if (trg_end == 0 ||
				iter->first.second > trg_end)
			{
				trg_end = iter->first.second;
			}
		}
	}
}
