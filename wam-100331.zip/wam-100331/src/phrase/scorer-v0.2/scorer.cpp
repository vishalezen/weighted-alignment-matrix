#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <vector>
#include <string>

using namespace std;

/************************************************
  version
************************************************/
void version()
{
	cout << "----------------------------------------\n"
		    " scorer v0.2\n"
			" 2010/03/02 - 2010/03/02\n"
			" (c) 2008-2010 Yang Liu\n"
			"----------------------------------------\n";
}

/************************************************
  load ttable
*************************************************/
void loadTTable(const char* fileName,
				map<pair<string, string>, float>& tTable)
{
	ifstream in(fileName);
	string line;

	while (getline(in, line))
	{
		istringstream iss(line.c_str());
		string srcWord,
			   trgWord;
		float prob;
		iss >> srcWord >> trgWord >> prob;
		pair<string, string> pr;
		pr.first = srcWord;
		pr.second = trgWord;
		tTable.insert(map<pair<string, string>, float>::value_type(pr, prob));
	}
}

/************************************************
  get translation probability
************************************************/
float getProb(const map<pair<string, string>, float>& tTable,
			  const string& srcWord,
			  const string& trgWord)
{
	pair<string, string> pr(srcWord, trgWord);

	map<pair<string, string>, float>::const_iterator iter = tTable.find(pr);

	if (iter == tTable.end())
	{
		return 1e-7;
	}
	else
	{
		return iter->second;
	}
}

/************************************************
  get word vector
************************************************/
void getWordVec(const string& line,
				vector<string>& wordVec)
{
	wordVec.clear();
	wordVec.push_back("$NULL");

	istringstream iss(line.c_str());
	string w;

	while (iss >> w)
	{
		wordVec.push_back(w);
	}
}

/************************************************
  get alignment
************************************************/
void getAlignment(const string& line,
				  map<pair<int, int>, float>& alignment)
{
	alignment.clear();

	istringstream iss(line.c_str());
	string w;

	while (iss >> w)
	{
		int spp1 = w.find(':'),
			spp2 = w.find('/'),
			sp = atoi(w.substr(0, spp1).c_str()),
			tp = atoi(w.substr(spp1 + 1, spp2 - spp1 - 1).c_str());
		float prob = atof(w.substr(spp2 + 1, (int)w.size() - spp2 - 1).c_str());
		alignment.insert(map<pair<int, int>, float>::value_type(pair<int, int>(sp, tp), prob));
	}
}

/************************************************
  calculate lexical weight
************************************************/
float lexWeight(const vector<string>& srcWordVec,
				const vector<string>& trgWordVec,
				const map<pair<int, int>, float>& alignment,
				const map<pair<string, string>, float>& tTable)
{
	float lw = 1.0;

	// consider each target word
	for (int i = 1; i < (int)trgWordVec.size(); i++)
	{
		float sum = 0,  // sum
			  p_aligned_to_null = 1.0;  // align to null
		int count = 0;  // count of aligned links

		map<pair<int, int>, float>::const_iterator iter;

		for (iter = alignment.begin(); iter != alignment.end(); iter++)
		{
			if (iter->first.second == i)
			{
				count++;
				float prob = getProb(tTable, 
					                 srcWordVec[iter->first.first],
									 trgWordVec[i]);
				sum += prob * iter->second;
				p_aligned_to_null *= 1.0 - iter->second;
			}
		}

		float prob = getProb(tTable, "$NULL", trgWordVec[i]);

		if (count > 0)
		{
			lw *= sum / count + prob * p_aligned_to_null;
		}
		else
		{
			lw *= prob * p_aligned_to_null;
		}
	}

	return lw;
}

/************************************************
  main function
************************************************/
int main(int argc, char** argv)
{
	// version
	version();

	if (argc != 6)
	{
		cerr << "Usage: scorer ruleTable1 ruleTable2 s2tTTable t2sTTable ruleTable" << endl;
		exit(1);
	}

	ifstream in1(argv[1]),
		     in2(argv[2]);
	ofstream out(argv[5]);
	map<pair<string, string>, float> s2tTTable,
		                             t2sTTable;
	loadTTable(argv[3], s2tTTable);
	loadTTable(argv[4], t2sTTable);

	string line1,  
		   line2;

	// line by line
	while (getline(in1, line1) &&
		   getline(in2, line2))
	{
		// source phrase
		int spp1 = 0,
			spp2 = line1.find(" ||| ", spp1);
		string srcPhrase = line1.substr(spp1, spp2 - spp1);
		vector<string> srcWordVec;
		getWordVec(srcPhrase, srcWordVec);

		// target phrase
		spp1 = spp2 + 5;
		spp2 = line1.find(" ||| ", spp1);
		string trgPhrase = line1.substr(spp1, spp2 - spp1);
		vector<string> trgWordVec;
		getWordVec(trgPhrase, trgWordVec);

		// alignment
		spp1 = spp2 + 5;
		spp2 = line1.find(" ||| ", spp1);
		string str = line1.substr(spp1, spp2 - spp1);
		map<pair<int, int>, float> alignment;
		getAlignment(str, alignment);

		// p(t|s)
		spp1 = spp2 + 5;
		spp2 = line1.size();
		float pst = atof(line1.substr(spp1, spp2 - spp1).c_str());

		// p(s|t)
		spp1 = 0;
		spp2 = line2.find(" ||| ", spp1);
		spp1 = spp2 + 5;
		spp2 = line2.find(" ||| ", spp1);
		spp1 = spp2 + 5;
		spp2 = line2.find(" ||| ", spp1);
		spp1 = spp2 + 5;
		spp2 = line2.size();
		float pts = atof(line2.substr(spp1, spp2 - spp1).c_str());

		// reverse alignment
		map<pair<int, int>, float> ra;

		map<pair<int, int>, float>::iterator iter;

		for (iter = alignment.begin(); iter != alignment.end(); iter++)
		{
			pair<int, int> pr(iter->first.second, iter->first.first);
			ra.insert(map<pair<int, int>, float>::value_type(pr, iter->second));
		}

		// lexical weights
		float lst = lexWeight(srcWordVec, trgWordVec, alignment, s2tTTable),
			  lts = lexWeight(trgWordVec, srcWordVec, ra, t2sTTable);

		out << srcPhrase
			<< " ||| "
			<< trgPhrase
			<< " ||| "
			<< str
			<< " ||| "
			<< pts
			<< " "
			<< lts
			<< " "
			<< pst
			<< " "
			<< lst
			<< endl;
	}

	return 0;
}
