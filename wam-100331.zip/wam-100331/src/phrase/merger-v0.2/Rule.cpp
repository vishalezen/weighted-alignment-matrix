#include <sstream>
#include "Rule.h"

/************************************************
  constructor
************************************************/
Rule::Rule()
{
}

/************************************************
  overload <<
************************************************/
ostream& operator<<(ostream& out, const Rule& right)
{
	out << right.srcPhrase
		<< " ||| "
		<< right.trgPhrase
		<< " ||| ";

	map<pair<int, int>, float>::const_iterator iter;

	for (iter = right.alignment.begin(); iter != right.alignment.end(); iter++)
	{
		out << iter->first.first
			<< ":"
			<< iter->first.second
			<< "/"
			<< iter->second
			<< " ";
	}

	return out;
}

/************************************************
  overload ==
************************************************/
bool Rule::operator==(const Rule& right) const
{
	if (srcPhrase == right.srcPhrase &&
		trgPhrase == right.trgPhrase &&
		alignment == right.alignment)
	{
		return true;
	}

	return false;
}

/************************************************
  overload =
************************************************/
Rule& Rule::operator=(const Rule& right)
{
	if (this != &right)
	{
		srcPhrase = right.srcPhrase;
		trgPhrase = right.trgPhrase;
		alignment = right.alignment;
	}

	return *this;
}

/************************************************
  overload <
************************************************/
bool Rule::operator<(const Rule& right) const
{
	if (srcPhrase < right.srcPhrase)
	{
		return true;
	}
	else if (srcPhrase == right.srcPhrase)
	{
		if (trgPhrase < right.trgPhrase)
		{
			return true;
		}
		else if (trgPhrase == right.trgPhrase)
		{
			if (alignment < right.alignment)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}
	else
	{
		return false;
	}
}

/************************************************
  overload >
************************************************/
bool Rule::operator>(const Rule& right) const
{
	if (srcPhrase > right.srcPhrase)
	{
		return true;
	}
	else if (srcPhrase == right.srcPhrase)
	{
		if (trgPhrase > right.trgPhrase)
		{
			return true;
		}
		else if (trgPhrase == right.trgPhrase)
		{
			if (alignment > right.alignment)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}
	else
	{
		return false;
	}
}
