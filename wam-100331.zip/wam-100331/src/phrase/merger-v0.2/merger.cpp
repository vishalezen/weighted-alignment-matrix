#include <fstream>
#include <sstream>
#include <vector>
#include "Rule.h"

/************************************************
  version
************************************************/
void version()
{
	cout << "----------------------------------------\n"
		    " merger v0.2\n"
			" 2010/03/02 - 2010/03/02\n"
			" (c) 2008-2010 Yang Liu\n"
			"----------------------------------------\n";
}

/************************************************
  main function
************************************************/
int main(int argc, char** argv)
{
	// version
	version();

	if (argc != 3)
	{
		cerr << "Usage: merge fileList output" << endl;
		exit(1);
	}

	ifstream in(argv[1]);
	ofstream out(argv[2]);
	vector<ifstream*> ifstreamPtrVec;
	string line;

	while (getline(in, line))
	{
		ifstream* ptr = new ifstream;
		ptr->open(line.c_str());
		ifstreamPtrVec.push_back(ptr);
	}

	vector<string> lineVec(ifstreamPtrVec.size(), "");
	vector<int> getNextVec(ifstreamPtrVec.size(), 1);
	vector<int> finishVec(ifstreamPtrVec.size(), 0);
	vector<pair<Rule, float> > dataVec(ifstreamPtrVec.size());

	while (1)
	{
		int i;

		for (i = 0; i < (int)getNextVec.size(); i++)
		{
			if (getNextVec[i] == 0)
			{
				continue;
			}

			if (getline(*ifstreamPtrVec[i], lineVec[i]))
			{
				string line = lineVec[i];
				
				// source phrase
				int spp1 = 0,
					spp2 = line.find(" ||| ", spp1);
				string srcPhrase = line.substr(spp1, spp2 - spp1);

				// target phrase
				spp1 = spp2 + 5;
				spp2 = line.find(" ||| ", spp1);
				string trgPhrase = line.substr(spp1, spp2 - spp1);

				// alignment
				spp1 = spp2 + 5;
				spp2 = line.find(" ||| ", spp1);
				map<pair<int, int>, float> alignment;
				istringstream iss(line.substr(spp1, spp2 - spp1).c_str());
				string w;

				while (iss >> w)
				{
					int spp1 = w.find(':'),
					    spp2 = w.find('/'),
						sp = atoi(w.substr(0, spp1).c_str()),
						tp = atoi(w.substr(spp1 + 1, spp2 - spp1 - 1).c_str());
					float prob = atof(w.substr(spp2 + 1, (int)w.size() - spp2 - 1).c_str());

					alignment.insert(map<pair<int, int>, float>::value_type(pair<int, int>(sp, tp), prob));
				}
				
				// frequency
				spp1 = spp2 + 5;
				spp2 = line.size();
				float freq = atof(line.substr(spp1, spp2 - spp1).c_str());

				Rule r;
				r.srcPhrase = srcPhrase;
				r.trgPhrase = trgPhrase;
				r.alignment = alignment;

				pair<Rule, float> pr;
				pr.first = r;
				pr.second = freq;
				dataVec[i] = pr;
			}
			else
			{
				finishVec[i] = 1;

				cout << "NO. "
					 << i + 1
					 << " file done!"
					 << endl;

				getNextVec[i] = 0;
			}
		}

		bool all_done = true;

		for (i = 0; i < (int)finishVec.size(); i++)
		{
			if (finishVec[i] == 0)
			{
				all_done = false;
				break;
			}
		}

		if (all_done)
		{
			break;
		}

		// minimum
		vector<int> minSctVec;

		for (i = 0; i < (int)dataVec.size(); i++)
		{
			if (finishVec[i])
			{
				continue;
			}

			bool min = true;

			for (int j = 0; j < (int)dataVec.size(); j++)
			{
				if (j == i ||
					finishVec[j])
				{
					continue;
				}

				if (dataVec[j].first < dataVec[i].first)
				{
					min = false;
					break;
				}
			}

			if (min)
			{
				minSctVec.push_back(i);
			}
		}

		// sums up
		float sum = 0;

		for (i = 0; i < (int)minSctVec.size(); i++)
		{
			sum += dataVec[minSctVec[i]].second;
		}

		// dump
		out << dataVec[minSctVec[0]].first
			<< "||| "
			<< sum
			<< endl;

		// update
		for (i = 0; i < (int)getNextVec.size(); i++)
		{
			getNextVec[i] = 0;
		}

		for (i = 0; i < (int)minSctVec.size(); i++)
		{
			getNextVec[minSctVec[i]] = 1;
		}
	}

	// avoid memory leak
	for (int i = 0; i < (int)ifstreamPtrVec.size(); i++)
	{
		delete ifstreamPtrVec[i];
	}

	return 0;
}
